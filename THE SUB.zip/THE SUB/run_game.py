"""
Entry point for the submarine simulation.
Initializes the game window and starts the simulation.
Enhanced version with combat systems and enemy behavior.
"""

import tkinter as tk 
from submarine_simulator.submarine_game import SubmarineSimulator

def main():
    """Main program entry point"""
    # Create the root window
    root = tk.Tk()
    
    # Set window title
    root.title("Submarine Combat Simulator")
    
    # Initialize the simulator
    app = SubmarineSimulator(root)
    
    # Start the main loop
    root.mainloop()

if __name__ == "__main__":
    main()
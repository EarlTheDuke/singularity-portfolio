"""
Main submarine simulator class.
Handles game logic, physics, and combat systems.
"""

import math
import time
import random
from collections import deque
from tkinter import messagebox

from .ship_classes import Ship, Torpedo, Projectile, SubmarinePhysics, Submarine
from .gui_elements import SubmarineGUI

class SubmarineSimulator:
    def __init__(self, root):
        """Initialize the submarine simulator."""
        self.root = root
        self.root.title("Submarine Control Panel")
        self.root.state('zoomed')
        
        # Initialize submarine physics
        self.submarine_physics = SubmarinePhysics()
        self.current_noise_level = self.submarine_physics.minimum_noise_level
        self.detection_status = {
            'is_detected': False,
            'detection_range': 250,
            'thermal_layer': 'surface',
            'detected_by': None,  # New field to track what detected us
            'contacts': []  # Add this line to initialize contacts list
        }
        
        # Initialize player submarine at center of map
        self.x_position = 2250  # Centered in 4500x4500 map
        self.y_position = 2250  # Centered in 4500x4500 map
        self.player_sub = Submarine(self.x_position, self.y_position, 0, "los_angeles", True)
        
        # Ship and submarine management
        self.ships = []
        self.enemy_submarines = []  # New list for enemy submarines
        
        # Combat system initialization
        self.torpedoes = []
        self.enemy_torpedoes = []
        self.enemy_projectiles = []
        self.hull_integrity = 100
        self.last_damage_time = 0
        self.damage_cooldown = 1.0
        self.torpedo_reload_time = 15.0
        self.last_torpedo_time = 0
        
        # Combat statistics
        self.combat_stats = {
            'torpedoes_fired': 0,
            'torpedo_hits': 0,
            'ships_sunk': 0,
            'submarines_sunk': 0,
            'damage_taken': 0
        }
        
        # Physics constants
        self.WATER_DENSITY = 1025.0
        self.SUB_VOLUME = 2000.0
        self.SUB_MASS = 2000000.0
        self.DRAG_COEFFICIENT = 0.5
        self.CROSS_SECTION = 50.0
        self.TURN_RATE = 0.0
        self.MAX_TURN_RATE = 15.0
        self.TURN_ACCELERATION = 5.0
        self.CRITICAL_DEPTH = 500.0
        self.SAFE_DEPTH = 300.0
        self.MAX_ACCELERATION = 8.0
        self.MAX_DECELERATION = 10.0
        self.WATER_RESISTANCE = 0.002
        self.TORPEDO_SPEED = 55.0
        
        # Depth failure tracking
        self.last_checked_depth = 0
        self.depth_check_interval = 25  # Increased to 25-meter intervals
        self.depth_checks_made = set()  # Track which depths we've already checked
        
        # Initialize submarine state
        self.depth = 0.0
        self.target_depth = 0.0
        self.speed = 0.0
        self.target_speed = 0.0
        self.heading = 0.0
        self.dive_angle = 0.0
        self.vertical_velocity = 0.0
        self.acceleration = 0.0
        self.max_depth_rate = 5.0
        
        # Initialize position tracking
        self.track_history = deque(maxlen=150)
        
        # Status indicators
        self.depth_warning = False
        self.speed_warning = False
        self.extreme_depth_warning = False
        
        # Time tracking
        self.last_update = time.time()
        self.game_over = False
        
        # Create GUI
        self.gui = SubmarineGUI(self.root, self)
        
        # Initialize heading to 0 (North)
        self.heading = 0.0
        self.gui.heading_slider.set(180)
        
        # Initialize enemy forces
        self.spawn_initial_forces()
        
        # Start physics update loop
        self.update_physics()

    def spawn_initial_forces(self, player_x=2250, player_y=2250):
        """
        Spawn initial enemy forces in tactically interesting positions around the player.
        Uses real-world inspired submarine warfare tactics.
        """
        # Clear existing forces
        self.ships = []
        self.enemy_submarines = []
        
        # Set up unit conversion
        KM_TO_UNIT = 25  # 1km = 25 units
        
        # Create threat rings at different ranges
        spawn_rings = [
            {
                "name": "close_threat",
                "range_km": 25,  # 25km close threats
                "count": {
                    "warship": 1,
                    "submarine": 1
                }
            },
            {
                "name": "medium_threat",
                "range_km": 35,  # 35km medium range
                "count": {
                    "warship": 2,
                    "submarine": 1
                }
            },
            {
                "name": "distant_threat",
                "range_km": 45,  # 45km distant threats
                "count": {
                    "warship": 2,
                    "merchant": 2
                }
            }
        ]
        
        # Spawn forces in each ring
        for ring in spawn_rings:
            radius = ring["range_km"] * KM_TO_UNIT
            
            # Spawn warships
            for _ in range(ring["count"].get("warship", 0)):
                angle = random.uniform(0, 360)
                actual_radius = radius * random.uniform(0.8, 1.2)
                
                x = player_x + actual_radius * math.cos(math.radians(angle))
                y = player_y + actual_radius * math.sin(math.radians(angle))
                
                heading = (math.degrees(math.atan2(player_x - x, player_y - y)) + 
                          random.uniform(-30, 30)) % 360
                
                ship = Ship(x, y, heading, "warship")
                ship.speed = random.uniform(10, 15)
                self.ships.append(ship)
                
            # Spawn submarines
            for _ in range(ring["count"].get("submarine", 0)):
                angle = random.uniform(0, 360)
                actual_radius = radius * random.uniform(0.8, 1.2)
                
                x = player_x + actual_radius * math.cos(math.radians(angle))
                y = player_y + actual_radius * math.sin(math.radians(angle))
                
                heading = (math.degrees(math.atan2(player_x - x, player_y - y)) + 
                          random.uniform(-45, 45)) % 360
                
                # Vary submarine types
                sub_type = random.choice(["yasen", "yasen"])
                sub = Submarine(x, y, heading, sub_type, False)
                
                # Assign depths based on range
                if ring["name"] == "close_threat":
                    sub.depth = random.uniform(100, 150)  # Hunting depth
                else:
                    sub.depth = random.uniform(150, 250)  # Transit depth
                    
                sub.speed = random.uniform(8, 12)
                self.enemy_submarines.append(sub)
            
            # Spawn merchants (only in distant ring)
            for _ in range(ring["count"].get("merchant", 0)):
                angle = random.uniform(0, 360)
                actual_radius = radius * random.uniform(0.9, 1.1)
                
                x = player_x + actual_radius * math.cos(math.radians(angle))
                y = player_y + actual_radius * math.sin(math.radians(angle))
                
                # Merchants move in straight lines across the area
                heading = random.uniform(0, 360)
                
                ship = Ship(x, y, heading, "merchant")
                ship.speed = random.uniform(8, 12)
                self.ships.append(ship)
                
        # Special spawn: Create a convoy group in the distant ring
        self._spawn_convoy_group(player_x, player_y, 40 * KM_TO_UNIT)  # 40km out

    def _spawn_convoy_group(self, player_x, player_y, distance):
        """Spawn a protected convoy group with escorts."""
        # Choose random direction for convoy
        convoy_angle = random.uniform(0, 360)
        convoy_x = player_x + distance * math.cos(math.radians(convoy_angle))
        convoy_y = player_y + distance * math.sin(math.radians(convoy_angle))
        
        # Convoy heading (perpendicular to player direction +/- 45°)
        base_heading = (convoy_angle + 90 + random.uniform(-45, 45)) % 360
        
        # Spawn merchant ships in formation
        merchant_positions = [
            (0, 0),      # Lead merchant
            (-100, -50), # Port merchant
            (100, -50),  # Starboard merchant
        ]
        
        for offset_x, offset_y in merchant_positions:
            # Rotate offset based on convoy heading
            rot_x = (offset_x * math.cos(math.radians(base_heading)) - 
                     offset_y * math.sin(math.radians(base_heading)))
            rot_y = (offset_x * math.sin(math.radians(base_heading)) + 
                     offset_y * math.cos(math.radians(base_heading)))
            
            ship = Ship(
                convoy_x + rot_x,
                convoy_y + rot_y,
                base_heading,
                "merchant"
            )
            ship.speed = random.uniform(8, 10)  # Convoy speed
            self.ships.append(ship)
        
        # Spawn escort warships
        escort_positions = [
            (-150, 100),   # Port bow escort
            (150, 100),    # Starboard bow escort
            (-150, -150),  # Port quarter escort
            (150, -150),   # Starboard quarter escort
        ]
        
        for offset_x, offset_y in escort_positions:
            # Rotate offset based on convoy heading
            rot_x = (offset_x * math.cos(math.radians(base_heading)) - 
                     offset_y * math.sin(math.radians(base_heading)))
            rot_y = (offset_x * math.sin(math.radians(base_heading)) + 
                     offset_y * math.cos(math.radians(base_heading)))
            
            ship = Ship(
                convoy_x + rot_x,
                convoy_y + rot_y,
                base_heading,
                "warship"
            )
            ship.speed = random.uniform(12, 15)  # Slightly faster than convoy
            self.ships.append(ship)
            
    def get_valid_contacts(self):
        """Get only contacts within detection range."""
        valid_contacts = []
        sonar_range = 1000  # Increased to ~40km (1000 units = 40km at 25 units per km)
        
        for contact in self.detection_status['contacts']:
            # Calculate true range
            dx = contact['x'] - self.x_position
            dy = contact['y'] - self.y_position
            true_range = math.hypot(dx, dy)
            
            # Adjust range based on thermal layer
            contact_layer = self.get_thermal_layer_status(contact.get('depth', 0))
            player_layer = self.get_thermal_layer_status(self.depth)
            
            range_modifier = 1.0
            if contact_layer != player_layer:
                range_modifier = 0.8  # Reduced cross-layer penalty
                
            max_detection_range = sonar_range * range_modifier
            
            # Only include contacts within modified range
            if true_range <= max_detection_range:
                contact['true_range'] = true_range
                valid_contacts.append(contact)
        
        # Sort by range
        return sorted(valid_contacts, key=lambda x: x.get('true_range', float('inf')))

    def update_ships(self, dt):
        """Update all ship positions and states"""
        ships_to_remove = []
        
        for ship in self.ships:
            if not ship.is_active:
                continue
                
            # Update heading with smoother turning
            if abs(ship.target_heading - ship.heading) > 0.1:
                heading_diff = (ship.target_heading - ship.heading + 180) % 360 - 180
                turn_amount = min(abs(heading_diff), ship.turn_rate * dt)
                if heading_diff < 0:
                    turn_amount = -turn_amount
                ship.heading = (ship.heading + turn_amount) % 360
            
            # Update position with improved movement
            heading_rad = math.radians(ship.heading)
            speed_factor = ship.speed * 0.025
            dx = math.sin(heading_rad) * speed_factor
            dy = -math.cos(heading_rad) * speed_factor
            
            ship.track_history.append((ship.x, ship.y))
            
            ship.x += dx
            ship.y += dy
            
            # Enhanced course changes
            if random.random() < 0.01:  # 1% chance per update
                max_turn = 30 if ship.ship_type == "merchant" else 45
                ship.target_heading = (ship.heading + random.uniform(-max_turn, max_turn)) % 360
                
                if random.random() < 0.2:  # 20% chance for major course change
                    ship.target_heading = random.uniform(0, 360)
            
            # Check if ship is off map (with buffer)
            if (ship.x < -100 or ship.x > 4600 or 
                ship.y < -100 or ship.y > 4600):
                ship.is_active = False
                ships_to_remove.append(ship)
        
        # Remove inactive ships
        for ship in ships_to_remove:
            if ship in self.ships:
                self.ships.remove(ship)
                
    def update_enemy_submarines(self, dt):
        """Update all enemy submarine positions and states with enhanced behavior."""
        current_time = time.time()
        subs_to_remove = []
        
        for sub in self.enemy_submarines:
            if not sub.is_active:
                continue
                
            # Update AI behavior
            sub.update_ai_behavior(current_time, self.player_sub)
            
            # Update submarine physics with improved movement
            # Calculate desired heading change
            heading_diff = (sub.target_heading - sub.heading + 180) % 360 - 180
            max_turn = sub.turn_rate * dt if hasattr(sub, 'turn_rate') else 2.0 * dt
            
            if abs(heading_diff) > max_turn:
                heading_diff = math.copysign(max_turn, heading_diff)
            sub.heading = (sub.heading + heading_diff) % 360
            
            # Update speed with acceleration/deceleration
            speed_diff = sub.target_speed - sub.speed
            if abs(speed_diff) > 0.1:
                acceleration = math.copysign(min(abs(speed_diff), 2.0 * dt), speed_diff)
                sub.speed = max(0, min(sub.max_speed, sub.speed + acceleration))
            
            # Update position
            heading_rad = math.radians(sub.heading)
            speed_factor = sub.speed * 0.025
            dx = math.sin(heading_rad) * speed_factor
            dy = -math.cos(heading_rad) * speed_factor
            
            # Store previous position for wake
            sub.track_history.append((sub.x, sub.y))
            
            # Update position with boundary checking
            new_x = sub.x + dx
            new_y = sub.y + dy
            
            # Keep submarine in bounds with realistic behavior
            if new_x < 50 or new_x > 4450:
                if sub.ai_state == "patrol":
                    sub.target_heading = (sub.heading + 180) % 360
                new_x = max(50, min(4450, new_x))
            if new_y < 50 or new_y > 4450:
                if sub.ai_state == "patrol":
                    sub.target_heading = (sub.heading + 180) % 360
                new_y = max(50, min(4450, new_y))
                
            sub.x = new_x
            sub.y = new_y
            
            # Update depth with smooth transitions
            depth_error = sub.target_depth - sub.depth
            if abs(depth_error) > 0.1:
                depth_change = math.copysign(min(abs(depth_error), sub.max_depth_rate * dt), depth_error)
                sub.depth = max(0, min(sub.max_depth, sub.depth + depth_change))
            
            # Update noise level and detection status
            sub.update_noise_level(current_time)
            
            # Handle torpedo firing with improved logic
            if sub.can_fire_torpedo(current_time) and sub.ai_state == "hunting":
                distance = math.hypot(self.x_position - sub.x, self.y_position - sub.y)
                if distance <= sub.torpedo_range and sub._should_fire_torpedo(self.player_sub):
                    torpedo = sub.fire_torpedo(sub.heading)
                    if torpedo:
                        self.enemy_torpedoes.append(torpedo)
                        print(f"Enemy submarine fired torpedo from {sub.x:.1f}, {sub.y:.1f}")

    def update_enemy_weapons(self, dt):
        """Update enemy weapon positions and check for hits with enhanced behavior."""
        # Update enemy torpedoes with improved guidance
        for torpedo in self.enemy_torpedoes[:]:
            if not torpedo.is_active:
                self.enemy_torpedoes.remove(torpedo)
                continue
            
            # Update torpedo position and tracking
            torpedo.update(dt, self.player_sub)
            
            # Check for submarine hit with improved collision detection
            distance = math.hypot(torpedo.x - self.x_position, torpedo.y - self.y_position)
            depth_difference = abs(torpedo.depth - self.depth)
            
            if distance < 15 and depth_difference < 20:  # More realistic hit detection
                damage = torpedo.calculate_damage(distance)
                self.handle_submarine_damage(damage)
                torpedo.is_active = False
                print(f"Player hit by torpedo! Damage: {damage:.1f}")
                continue
            
            # Remove if too far or too old
            if (torpedo.x < 0 or torpedo.x > 4500 or 
                torpedo.y < 0 or torpedo.y > 4500 or
                not torpedo.is_active):
                self.enemy_torpedoes.remove(torpedo)

    def update_enemy_targeting(self, dt):
        """Handle enemy ship and submarine targeting and firing."""
        current_time = time.time()
        
        # Update submarine noise and detection status
        self.update_noise_levels()
        self.update_detection_status()
        
        # Surface ship targeting
        for ship in self.ships:
            if not ship.is_active or not ship.has_weapons:
                continue
                
            distance = ship.get_distance_to_target(self.x_position, self.y_position)
            is_detected, detection_range = self.submarine_physics.is_detectable(
                current_time,
                (ship.x, ship.y),
                (self.x_position, self.y_position),
                self.speed,
                self.depth
            )
            
            # Only target if submarine is detected
            if is_detected:
                # Surface gun targeting
                if self.depth <= 10 and distance <= ship.gun_range:
                    if ship.can_fire_guns(current_time):
                        self.enemy_fire_guns(ship)
                        ship.last_gun_shot = current_time
                
                # Torpedo targeting
                if distance <= ship.torpedo_range:
                    if ship.can_fire_torpedo(current_time):
                        self.enemy_fire_torpedo(ship)
                        ship.last_torpedo_shot = current_time
                        
    # Enemy submarine targeting
        for sub in self.enemy_submarines:
            if not sub.is_active:
                continue
            
            # Check if enemy sub can detect player
            is_detected, detection_range = sub.detect_target(self.player_sub)
            
            if is_detected:
                distance = sub.get_distance_to_target(self.x_position, self.y_position)
                
                # Update AI state for targeting
                if sub.ai_state != "hunting":
                    sub.ai_state = "hunting"
                    sub.last_known_contact = (self.x_position, self.y_position, self.depth)
                
                # Fire torpedo if conditions are met
                if distance <= sub.torpedo_range:
                    if sub.can_fire_torpedo(current_time):
                        torpedo = sub.fire_torpedo(sub.calculate_target_bearing(
                            self.x_position, self.y_position))
                        if torpedo:
                            self.enemy_torpedoes.append(torpedo)

    def enemy_fire_guns(self, ship):
        """Handle enemy ship firing guns."""
        lead_time = 1.0
        target_x = self.x_position + (math.sin(math.radians(self.heading)) * 
                                    self.speed * 0.025 * lead_time)
        target_y = self.y_position - (math.cos(math.radians(self.heading)) * 
                                    self.speed * 0.025 * lead_time)
        
        base_angle = ship.calculate_target_bearing(target_x, target_y)
        firing_angle = base_angle + random.uniform(-5, 5)
        
        projectile = Projectile(ship.x, ship.y, firing_angle)
        self.enemy_projectiles.append(projectile)

    def enemy_fire_torpedo(self, ship):
        """Handle enemy ship firing torpedo."""
        lead_time = 2.0
        target_x = self.x_position + (math.sin(math.radians(self.heading)) * 
                                    self.speed * 0.025 * lead_time)
        target_y = self.y_position - (math.cos(math.radians(self.heading)) * 
                                    self.speed * 0.025 * lead_time)
        
        base_angle = ship.calculate_target_bearing(target_x, target_y)
        firing_angle = base_angle + random.uniform(-3, 3)
        
        torpedo = Torpedo(ship.x, ship.y, firing_angle, friendly=False)
        self.enemy_torpedoes.append(torpedo)

    def handle_submarine_damage(self, damage):
        """Process damage to the submarine."""
        current_time = time.time()
        if current_time - self.last_damage_time < self.damage_cooldown:
            return
            
        self.last_damage_time = current_time
        self.hull_integrity -= damage
        self.combat_stats['damage_taken'] += damage
        
        if self.hull_integrity <= 0:
            self.handle_submarine_destruction()
        else:
            messagebox.showwarning(
                "Damage Alert",
                f"Hull damage sustained!\nIntegrity: {self.hull_integrity:.1f}%"
            )

    def handle_submarine_destruction(self):
        """Handle submarine being destroyed."""
        self.game_over = True
        messagebox.showerror(
            "VESSEL LOST",
            "Critical damage sustained!\nSubmarine lost with all hands."
        )

    def check_collisions(self):
        """Check for collisions between torpedoes/submarine and ships/submarines"""
        self.check_torpedo_hits()
        self.check_surface_collisions()
        self.check_submarine_collisions()

    def check_torpedo_hits(self):
        """Check for torpedo hits on all vessels."""
        for torpedo in self.torpedoes[:]:
            if not torpedo.is_active:
                continue
            
            # Check hits on surface ships
            for ship in self.ships:
                if not ship.is_active:
                    continue
                    
                distance = math.hypot(torpedo.x - ship.x, torpedo.y - ship.y)
                if distance < (ship.length / 2 + torpedo.size):
                    self.handle_torpedo_hit(torpedo, ship)
                    
            # Check hits on enemy submarines
            for sub in self.enemy_submarines:
                if not sub.is_active:
                    continue
                    
                distance = math.hypot(torpedo.x - sub.x, torpedo.y - sub.y)
                depth_diff = abs(self.depth - sub.depth)
                
                if distance < (sub.length / 2 + torpedo.size) and depth_diff < 50:
                    self.handle_submarine_hit(torpedo, sub)
                    
    def handle_torpedo_hit(self, torpedo, target):
        """Handle torpedo hit on a vessel."""
        torpedo.is_active = False
        self.combat_stats['torpedo_hits'] += 1
        
        damage = random.uniform(0.9, 1.1) * torpedo.damage
        target.health -= damage
        
        if target.health <= 0:
            target.is_active = False
            if isinstance(target, Ship):
                self.combat_stats['ships_sunk'] += 1
                self.handle_ship_destruction(target)
            elif isinstance(target, Submarine):
                self.combat_stats['submarines_sunk'] += 1
                self.handle_submarine_destruction(target)

    def check_surface_collisions(self):
        """Check for collisions with surface ships."""
        if self.depth <= 10.0:
            for ship in self.ships:
                if not ship.is_active:
                    continue
                
                distance = math.hypot(self.x_position - ship.x, self.y_position - ship.y)
                collision_threshold = (ship.length / 2) + 25
                
                if distance < collision_threshold:
                    self.handle_surface_collision(ship)
                    return

    def check_submarine_collisions(self):
        """Check for collisions between submarines."""
        for enemy_sub in self.enemy_submarines:
            if not enemy_sub.is_active:
                continue
                
            # Only check collision if depth difference is within 10m
            depth_diff = abs(self.depth - enemy_sub.depth)
            if depth_diff > 10:  # Skip if depth difference is more than 10m
                continue
                
            distance = math.hypot(self.x_position - enemy_sub.x, 
                                self.y_position - enemy_sub.y)
            collision_threshold = (enemy_sub.length / 2) + 25
            
            if distance < collision_threshold:
                self.handle_submarine_collision(enemy_sub)
                return

    def handle_surface_collision(self, ship):
        """Handle collision with surface ship."""
        self.handle_submarine_damage(self.hull_integrity)
        
        collision_depth = f"{self.depth:.1f}"
        ship_type = ship.ship_type.capitalize()
        
        messagebox.showerror(
            "COLLISION!", 
            f"CATASTROPHIC COLLISION WITH {ship_type} VESSEL!\n"
            f"Collision occurred at depth: {collision_depth}m\n"
            f"Speed at impact: {self.speed:.1f} knots\n"
            f"Submarine lost with all hands."
        )

    def handle_submarine_collision(self, other_sub):
        """Handle collision between submarines."""
        self.handle_submarine_damage(self.hull_integrity)
        other_sub.is_active = False
        
        collision_depth = f"{self.depth:.1f}"
        sub_type = other_sub.name
        depth_diff = abs(self.depth - other_sub.depth)
        
        messagebox.showerror(
            "COLLISION!", 
            f"CATASTROPHIC COLLISION WITH {sub_type}!\n"
            f"Collision occurred at depth: {collision_depth}m\n"
            f"Depth difference: {depth_diff:.1f}m\n"
            f"Speed at impact: {self.speed:.1f} knots\n"
            f"Submarine lost with all hands."
        )

    def handle_ship_destruction(self, ship):
        """Handle the destruction of a ship"""
        self.gui.animate_explosion(ship.x, ship.y)
        
        if ship.ship_type == "warship":
            for _ in range(2):
                offset_x = random.uniform(-ship.length/2, ship.length/2)
                offset_y = random.uniform(-ship.width/2, ship.width/2)
                self.root.after(random.randint(100, 500), 
                              lambda x=ship.x+offset_x, y=ship.y+offset_y: 
                              self.gui.animate_explosion(x, y))
        
        ship.speed = 0
        
        def remove_ship():
            if ship in self.ships:
                self.ships.remove(ship)
        
        self.root.after(20000, remove_ship)

    def handle_submarine_hit(self, torpedo, sub):
        """Handle torpedo hit on an enemy submarine."""
        torpedo.is_active = False
        self.combat_stats['torpedo_hits'] += 1
        
        damage = random.uniform(0.9, 1.1) * torpedo.damage
        sub.health -= damage
        
        if sub.health <= 0:
            sub.is_active = False
            self.combat_stats['submarines_sunk'] += 1
            self.handle_enemy_submarine_destruction(sub)

    def handle_enemy_submarine_destruction(self, sub):
        """Handle the destruction of an enemy submarine."""
        self.gui.animate_explosion(sub.x, sub.y)
        
        # Multiple explosions for dramatic effect
        for _ in range(3):
            offset_x = random.uniform(-sub.length/2, sub.length/2)
            offset_y = random.uniform(-sub.width/2, sub.width/2)
            self.root.after(random.randint(100, 500), 
                          lambda x=sub.x+offset_x, y=sub.y+offset_y: 
                          self.gui.animate_explosion(x, y))
        
        def remove_submarine():
            if sub in self.enemy_submarines:
                self.enemy_submarines.remove(sub)
        
        self.root.after(20000, remove_submarine)
        
    def update_physics(self):
        """Main physics update loop with submarine warfare additions."""
        if self.game_over:
            return
        
        current_time = time.time()
        dt = min(current_time - self.last_update, 0.1)
        self.last_update = current_time
        
        if self.check_hull_failure(dt):
            return
        
        # Update sequence
        self.update_noise_levels()
        self.update_detection_status()
        self.update_ships(dt)
        self.update_enemy_submarines(dt)
        self.update_torpedoes(dt)
        self.update_enemy_targeting(dt)
        self.update_enemy_weapons(dt)
        self.check_collisions()
        
        # Update player submarine physics
        self.update_player_physics(dt)
        self.gui.update_layer_status(self.get_thermal_layer_status())
        
        # Update GUI elements
        self.gui.update_display_values(self.depth, self.speed, self.heading)
        self.gui.update_submarine_position()
        self.gui.update_compass_view()
        self.gui.update_map_position()
        self.gui.update_sonar_contacts(self.ships, self.enemy_submarines, 
                                     self.x_position, self.y_position, self.heading)
        self.gui.update_combat_stats(self.combat_stats, self.hull_integrity)
        
        # Update displays
        self.gui.update_depth_warnings(self.depth)
        self.gui.update_torpedo_button_state(current_time - self.last_torpedo_time, 
                                           self.torpedo_reload_time)
        
        # Schedule next update
        self.root.after(33, self.update_physics)

    def update_player_physics(self, dt):
        """Update player submarine physics."""
        # Calculate acceleration based on target speed
        speed_diff = self.target_speed - self.speed
        if speed_diff > 0:
            self.acceleration = min(speed_diff, self.MAX_ACCELERATION * (1 - self.speed/30))
        else:
            self.acceleration = max(speed_diff, -self.MAX_DECELERATION * (self.speed/30 + 0.5))
        
        resistance = -math.copysign(self.speed * self.speed * self.WATER_RESISTANCE, self.speed)
        
        self.speed += (self.acceleration + resistance) * dt
        self.speed = max(0, min(30, self.speed))
        
        # Update depth based on target
        depth_error = self.target_depth - self.depth
        desired_velocity = depth_error * 0.8
        
        if abs(desired_velocity) > self.max_depth_rate:
            desired_velocity = math.copysign(self.max_depth_rate, desired_velocity)
        
        self.vertical_velocity = (self.vertical_velocity * 0.8 + desired_velocity * 0.2)
        
        self.depth += self.vertical_velocity * dt
        self.depth = max(0, self.depth)  # Only limit minimum depth
        
        # Update heading based on turn rate
        if abs(self.TURN_RATE) > 0:
            turn_effectiveness = min(1.0, self.speed / 15.0)
            actual_turn = self.TURN_RATE * dt * turn_effectiveness
            self.heading = (self.heading + actual_turn) % 360
        
        # Update position based on speed and heading
        if self.speed > 0:
            heading_rad = math.radians(self.heading)
            speed_factor = self.speed * 0.025
            dx = math.sin(heading_rad) * speed_factor
            dy = -math.cos(heading_rad) * speed_factor
            
            # Add current position to track history before updating
            self.track_history.append((self.x_position, self.y_position))
            
            new_x = self.x_position + dx
            new_y = self.y_position + dy
            
            # Handle map boundaries with expanded dimensions
            if new_x < 50 or new_x > 4450:  # Full map boundaries with buffer
                dx *= -0.5
                new_x = max(50, min(4450, new_x))
            if new_y < 50 or new_y > 4450:  # Full map boundaries with buffer
                dy *= -0.5
                new_y = max(50, min(4450, new_y))
            
            self.x_position = new_x
            self.y_position = new_y
            
            # Update player submarine position
            self.player_sub.x = self.x_position
            self.player_sub.y = self.y_position
            self.player_sub.depth = self.depth
            self.player_sub.heading = self.heading
            self.player_sub.speed = self.speed

    def update_noise_levels(self):
        """Update submarine's noise level."""
        self.current_noise_level = self.player_sub.physics.calculate_noise_level(
            self.speed, self.depth
        )
        
    def get_thermal_layer_status(self):
        """Get current thermal layer based on depth."""
        if self.depth <= self.submarine_physics.surface_layer_depth:
            return 'surface'
        elif (self.depth >= self.submarine_physics.thermocline_layer_start and 
              self.depth <= self.submarine_physics.thermocline_layer_end):
            return 'thermocline'
        else:
            return 'deep'

    def update_detection_status(self):
        """Update submarine's detection status with dramatically enhanced detection ranges."""
        self.detection_status['is_detected'] = False
        self.detection_status['thermal_layer'] = self.get_thermal_layer_status()
        self.detection_status['detected_by'] = None
        self.detection_status['contacts'] = []
        
        current_time = time.time()
        
        # Force surface detection regardless of range when surfaced
        if self.depth <= 10:
            for ship in self.ships:
                if not ship.is_active:
                    continue
                
                dx = ship.x - self.x_position
                dy = ship.y - self.y_position
                true_range = math.hypot(dx, dy)
                range_km = true_range / 25
                bearing = (math.degrees(math.atan2(dx, -dy)) - self.heading) % 360
                
                # Update detection status for surface ships
                if ship.has_weapons and true_range <= ship.detection_range:
                    self.detection_status['is_detected'] = True
                    self.detection_status['detected_by'] = ship
                
                # Add all surface ships as visible contacts
                contact = {
                    'type': 'surface_ship',
                    'ship': ship,
                    'x': ship.x,
                    'y': ship.y,
                    'strength': 1.0,
                    'bearing': bearing,
                    'bearing_quality': 1.0,
                    'range': f"{range_km:.1f}",
                    'speed': ship.speed,
                    'confidence': 1.0,
                    'depth': 0,
                    'layer': 'SURFACE',
                    'solution': 'FIRM',
                    'is_visible': True
                }
                self.detection_status['contacts'].append(contact)
        
        # Enhanced submerged detection with extreme ranges
        else:
            # Process surface ships with 32x range (doubled from 16x)
            for ship in self.ships:
                if not ship.is_active:
                    continue
                
                dx = ship.x - self.x_position
                dy = ship.y - self.y_position
                true_range = math.hypot(dx, dy)
                range_km = true_range / 25
                bearing = (math.degrees(math.atan2(dx, -dy)) - self.heading) % 360
                
                # Dramatically increased detection range
                max_sonar_range = 8000 * (1.0 - (self.depth / 500))  # 32x original range
                if true_range <= max_sonar_range:
                    strength = 0.8 * (1.0 - (true_range / max_sonar_range))
                    bearing_quality = 0.9 * (1.0 - (true_range / max_sonar_range))
                    
                    # Update detection status for ships
                    if ship.has_weapons and true_range <= (ship.detection_range * 2):  # Double ship detection range
                        self.detection_status['is_detected'] = True
                        self.detection_status['detected_by'] = ship
                    
                    contact = {
                        'type': 'surface_ship',
                        'ship': ship,
                        'x': ship.x,
                        'y': ship.y,
                        'strength': strength,
                        'bearing': bearing,
                        'bearing_quality': bearing_quality,
                        'range': f"{range_km:.1f}",
                        'speed': ship.speed,
                        'confidence': 0.8,
                        'depth': 0,
                        'layer': 'SURFACE',
                        'solution': self._get_solution_quality(strength),
                        'is_visible': True
                    }
                    self.detection_status['contacts'].append(contact)
        
        # Process enemy submarines with enhanced detection
        for enemy_sub in self.enemy_submarines:
            if not enemy_sub.is_active:
                continue
            
            # Use 32x range for submarine detection (doubled from 16x)
            is_detected, strength, bearing_quality = self.player_sub.calculate_passive_sonar_detection(
                enemy_sub, range_multiplier=32.0)
            
            if is_detected:
                true_range = math.hypot(enemy_sub.x - self.x_position, 
                                      enemy_sub.y - self.y_position)
                range_km = true_range / 25
                bearing = (math.degrees(math.atan2(
                    enemy_sub.x - self.x_position,
                    -(enemy_sub.y - self.y_position))) - self.heading) % 360
                
                # Update detection status for submarines
                if true_range <= (enemy_sub.detection_range * 2):  # Double sub detection range
                    self.detection_status['is_detected'] = True
                    self.detection_status['detected_by'] = enemy_sub
                
                contact = {
                    'type': 'submarine',
                    'sub': enemy_sub,
                    'x': enemy_sub.x,
                    'y': enemy_sub.y,
                    'strength': strength,
                    'bearing': bearing,
                    'bearing_quality': bearing_quality,
                    'range': f"{range_km:.1f}",
                    'speed': enemy_sub.speed,
                    'confidence': self.player_sub.calculate_contact_confidence(
                        strength, bearing_quality),
                    'depth': enemy_sub.depth,
                    'layer': self.get_thermal_layer_status(enemy_sub.depth),
                    'solution': self._get_solution_quality(strength)
                }
                self.detection_status['contacts'].append(contact)
                
        # Reset is_detected status if torpedo was recently fired
        if current_time - self.last_torpedo_time < self.submarine_physics.torpedo_firing_detection_time:
            self.detection_status['is_detected'] = True

    def update_contact_display(self):
        """Update enhanced contact display with uncertainty circles."""
        # Clear previous contact overlays
        self.map_canvas.delete("contact")
        self.map_canvas.delete("contact_uncertainty")
        self.map_canvas.delete("contact_label")
        
        # Get valid contacts from simulator
        valid_contacts = self.sim.get_valid_contacts()
        
        for contact in valid_contacts:
            uncertainty_radius = self._get_uncertainty_radius(contact)
            solution_color = self._get_contact_color(contact['solution'])
            
            try:
                # Calculate position in map coordinates
                if 'x' not in contact or 'y' not in contact:
                    range_km = float(contact['range'])
                    bearing_rad = math.radians(float(contact['bearing']))
                    x = self.sim.x_position + (range_km * 25 * math.sin(bearing_rad))
                    y = self.sim.y_position - (range_km * 25 * math.cos(bearing_rad))
                else:
                    x = float(contact['x'])
                    y = float(contact['y'])
                
                # Draw main uncertainty circle
                self._draw_uncertainty_circle(x, y, uncertainty_radius, solution_color)
                
                # Add contact labels
                self._draw_contact_labels(x, y, uncertainty_radius, contact)
                
            except (ValueError, KeyError) as e:
                print(f"Error processing contact: {str(e)}")

    def _get_solution_quality(self, strength):
        """Determine solution quality based on signal strength."""
        if strength >= 0.8:
            return "FIRM"
        elif strength >= 0.5:
            return "WEAK"
        return "UNCERTAIN"

    def get_thermal_layer_status(self, depth=None):
        """Get current thermal layer based on depth."""
        if depth is None:
            depth = self.depth
        
        if depth <= self.submarine_physics.surface_layer_depth:
            return 'SURFACE'
        elif (depth >= self.submarine_physics.thermocline_layer_start and 
              depth <= self.submarine_physics.thermocline_layer_end):
            return 'THERMOCLINE'
        else:
            return 'DEEP'

    def update_sonar_contacts(self):
        """Update sonar contacts with enhanced detection information."""
        # This method will be called from update_physics
        self.update_detection_status()
        
        # Pass the enhanced contact information to the GUI
        self.gui.update_sonar_display(
            self.detection_status['contacts'],
            self.ships,
            self.x_position,
            self.y_position,
            self.heading
        )

    def fire_torpedo(self):
        """Fire a torpedo from the submarine's current position with debugging."""
        current_time = time.time()
        
        # Debug print for timing
        print(f"Attempting to fire torpedo. Time since last: {current_time - self.last_torpedo_time:.1f}s")
        print(f"Reload time required: {self.torpedo_reload_time}s")
        
        if current_time - self.last_torpedo_time < self.torpedo_reload_time:
            print("Cannot fire - still reloading")
            return
        
        # Create torpedo using player submarine with proper positioning
        spawn_distance = 20  # Distance ahead of submarine to spawn torpedo
        heading_rad = math.radians(self.heading)
        spawn_x = self.x_position + spawn_distance * math.sin(heading_rad)
        spawn_y = self.y_position - spawn_distance * math.cos(heading_rad)
        
        torpedo = Torpedo(spawn_x, spawn_y, self.heading, friendly=True, launch_depth=self.depth)
        if torpedo:
            self.torpedoes.append(torpedo)
            self.last_torpedo_time = current_time
            self.submarine_physics.update_torpedo_firing(current_time)
            self.combat_stats['torpedoes_fired'] += 1
            print(f"Torpedo fired! Position: ({spawn_x:.1f}, {spawn_y:.1f}), Heading: {self.heading}°")
        else:
            print("Failed to create torpedo")

    def update_torpedoes(self, dt):
        """Update positions of all torpedoes with improved movement."""
        # Update player torpedoes
        for torpedo in self.torpedoes[:]:
            if not torpedo.is_active:
                print("Removing inactive torpedo")
                self.torpedoes.remove(torpedo)
                continue
            
            # Calculate movement
            heading_rad = math.radians(torpedo.heading)
            speed_factor = torpedo.speed * 0.025
            dx = math.sin(heading_rad) * speed_factor
            dy = -math.cos(heading_rad) * speed_factor
            
            # Store previous position for wake
            torpedo.track_history.append((torpedo.x, torpedo.y))
            
            # Update position
            torpedo.x += dx
            torpedo.y += dy
            
            # Print debug info occasionally
            if random.random() < 0.05:  # 5% chance each update
                print(f"Active torpedo at ({torpedo.x:.1f}, {torpedo.y:.1f}), Heading: {torpedo.heading}°")
            
            # Check if torpedo is off map
            if (torpedo.x < 0 or torpedo.x > 4500 or 
                torpedo.y < 0 or torpedo.y > 4500):
                print(f"Torpedo went out of bounds at ({torpedo.x:.1f}, {torpedo.y:.1f})")
                self.torpedoes.remove(torpedo)

    def check_hull_failure(self, dt):
        """Check for potential hull failure with very forgiving chances"""
        if self.depth < self.SAFE_DEPTH:
            self.last_checked_depth = 0
            self.depth_checks_made.clear()  # Reset checks when returning to safe depth
            return False
            
        # Calculate current depth zone (rounded to nearest 25m)
        current_zone = round(self.depth / self.depth_check_interval) * self.depth_check_interval
        
        # Only check if we've moved to a new depth zone AND haven't checked it before
        if current_zone > self.last_checked_depth and current_zone not in self.depth_checks_made:
            self.last_checked_depth = current_zone
            self.depth_checks_made.add(current_zone)  # Remember we've checked this depth
            
            # Calculate failure chance for this depth - MUCH more forgiving
            depth_factor = (self.depth - self.SAFE_DEPTH) / (495 - self.SAFE_DEPTH)
            depth_factor = max(0, min(1, depth_factor))
            
            # Very low base chance that increases slowly with depth
            # 0.5% at 300m, rising to 5% at 495m
            failure_chance = 0.005 + (depth_factor * 0.045)
            
            # Single random check for this depth
            if random.random() < failure_chance:
                self.game_over = True
                if self.depth >= 495:
                    messagebox.showerror(
                        "EXTREME DEPTH FAILURE",
                        f"CRITICAL HULL STRESS!\n"
                        f"Hull failed at {self.depth:.1f}m\n"
                        f"Maximum survivable depth exceeded"
                    )
                else:
                    messagebox.showerror(
                        "HULL STRESS FAILURE",
                        f"PRESSURE HULL BREACH!\n"
                        f"Hull failed at {self.depth:.1f}m\n"
                        f"Failure chance at this depth: {failure_chance*100:.2f}%"
                    )
                return True
                
        return False

    def on_depth_slide(self, value):
        """Handle depth slider changes with no artificial limits"""
        if not self.game_over:
            self.target_depth = float(value)  # No depth restrictions

    def on_speed_slide(self, value):
        """Handle speed slider changes"""
        if not self.game_over:
            self.target_speed = float(value)

    def on_heading_slide(self, value):
        """Handle heading slider changes"""
        if not self.game_over:
            turn_input = (float(value) - 180) / 180
            self.TURN_RATE = turn_input * self.MAX_TURN_RATE
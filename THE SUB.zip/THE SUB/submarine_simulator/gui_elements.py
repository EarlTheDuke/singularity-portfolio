"""
GUI elements for the submarine simulation.
Contains all visualization and user interface components.
Enhanced with submarine warfare visualization capabilities.
"""

import logging
import tkinter as tk
from tkinter import ttk, messagebox
import math
import time
import random
from .ship_classes import Ship, Torpedo, Projectile, Submarine

class SubmarineGUI:
    def __init__(self, root, simulator):
        self.last_center_time = 0
        self.center_cooldown = 100  # Seconds between centering checks
        """Initialize the GUI elements."""
        self.root = root
        self.sim = simulator
        
        # Initialize canvas references
        self.side_canvas = None
        self.map_canvas = None
        self.compass_canvas = None
        self.sub_shape = None
        self.map_sub = None
        self.compass_sub = None
        
        # Initialize control references
        self.depth_slider = None
        self.speed_slider = None
        self.heading_slider = None
        self.torpedo_button = None
        self.depth_warning_label = None
        self.extreme_depth_warning_label = None
        self.speed_warning_label = None
        self.depth_risk_label = None
        
        # Initialize display variables
        self.depth_var = tk.StringVar(value="0")
        self.speed_var = tk.StringVar(value="0")
        self.heading_var = tk.StringVar(value="0")
        
        # Track active explosions
        self.active_explosions = []
        
        # Create info frame first
        self.info_frame = ttk.Frame(self.root)
        self.info_frame.grid(row=1, column=2, padx=15, pady=5, sticky="ne")
        self.info_frame.grid_columnconfigure(0, minsize=270)
        
        # Initialize sonar display
        self.sonar_display = SonarContactDisplay(self.info_frame)
        self.sonar_display.frame.pack(fill="y", pady=(0, 5), expand=False)
        
        # Set up the GUI
        self.setup_gui()
        
        # Initialize heading to 0 (North)
        self.heading = 0.0
        if self.heading_slider:
            self.heading_slider.set(180)
            self.setup_debug()
            
    def setup_debug(self):
        """Initialize debug logging."""
        logging.basicConfig(level=logging.DEBUG)
        self.logger = logging.getLogger(__name__)
        
    # Add these methods to the SubmarineGUI class in gui_elements.py
    
    def center_initial_view(self):
        """Center the map view on submarine's initial position."""
        # Get viewport dimensions
        viewport_width = self.map_canvas.winfo_width()
        viewport_height = self.map_canvas.winfo_height()
        
        # Get scaled submarine position
        sub_x = self.sim.x_position * self.scale_factor
        sub_y = self.sim.y_position * self.scale_factor
        
        # Calculate scroll fractions to center the submarine
        scroll_x = (sub_x - viewport_width/2) / (4500 * self.scale_factor)
        scroll_y = (sub_y - viewport_height/2) / (4500 * self.scale_factor)
        
        # Ensure scroll values are within bounds (0 to 1)
        scroll_x = max(0, min(1, scroll_x))
        scroll_y = max(0, min(1, scroll_y))
        
        # Move the view
        self.map_canvas.xview_moveto(scroll_x)
        self.map_canvas.yview_moveto(scroll_y)
    
    def _get_uncertainty_radius(self, contact):
        """Calculate display radius based on multiple factors."""
        # Base radius in map units
        base_radius = 25
        
        # Get scaling factors
        range_factor = self._get_range_uncertainty(contact)
        solution_factor = self._get_solution_factor(contact['solution'])
        layer_factor = self._get_layer_uncertainty_factor(contact)
        speed_factor = self._get_speed_uncertainty_factor(contact)
        
        # Combine all factors
        final_radius = base_radius * range_factor * solution_factor * layer_factor * speed_factor
        
        # Ensure minimum and maximum reasonable sizes
        return max(15, min(final_radius, 150))
    
    def _get_range_uncertainty(self, contact):
        """Calculate uncertainty factor based on range."""
        # Convert range to kilometers (assuming range is stored in km)
        try:
            range_km = float(contact['range'].replace('km', ''))
        except (ValueError, AttributeError):
            range_km = 0
            
        # Uncertainty increases with range
        # 1.0 at 0km, 2.0 at 20km, 3.0 at 40km
        range_factor = 1.0 + (range_km / 20.0)
        
        return min(3.0, range_factor)
    
    def _get_layer_uncertainty_factor(self, contact):
        """Calculate uncertainty factor based on thermal layer."""
        # Get the layers
        try:
            contact_layer = contact['layer']
            player_layer = self.sim.detection_status['thermal_layer']
        except (KeyError, AttributeError):
            return 1.5
        
        # Same layer has less uncertainty
        if contact_layer == player_layer:
            return 1.0
            
        # Layer transitions increase uncertainty
        if 'THERMOCLINE' in (contact_layer, player_layer):
            return 2.0
            
        # Surface to deep has highest uncertainty
        return 2.5
    
    def _get_speed_uncertainty_factor(self, contact):
        """Calculate uncertainty factor based on relative speed."""
        try:
            contact_speed = float(contact['speed'])
            player_speed = self.sim.speed
        except (ValueError, AttributeError):
            return 1.0
            
        # Higher speeds increase uncertainty
        relative_speed = abs(contact_speed - player_speed)
        speed_factor = 1.0 + (relative_speed / 20.0)
        
        return min(2.0, speed_factor)
    
    def _get_solution_factor(self, solution):
        """Get scaling factor based on solution quality."""
        return {
            'FIRM': 1.0,
            'WEAK': 1.5,
            'UNCERTAIN': 2.0
        }.get(solution, 2.0)
    
    def _get_contact_color(self, solution):
        """Get color based on solution quality with enhanced visibility."""
        return {
            'FIRM': '#00ff00',   # Bright green
            'WEAK': '#ffff00',   # Yellow
            'UNCERTAIN': '#ff0000'  # Red
        }.get(solution, '#808080')  # Gray as fallback
    
    def _draw_contact_uncertainty(self, contact):
        """Draw enhanced contact uncertainty circle on map with debug info."""
        # Calculate uncertainty radius
        uncertainty_radius = self._get_uncertainty_radius(contact)
        print(f"Drawing uncertainty circle with radius {uncertainty_radius}")
        
        # Get base color from solution quality
        base_color = self._get_contact_color(contact['solution'])
        print(f"Using color {base_color} for solution quality {contact['solution']}")
        
        try:
            # Convert range and bearing to x,y if not present
            if 'x' not in contact or 'y' not in contact:
                range_km = float(contact['range'])
                bearing_rad = math.radians(float(contact['bearing']))
                x = self.sim.x_position + (range_km * 25 * math.sin(bearing_rad))
                y = self.sim.y_position - (range_km * 25 * math.cos(bearing_rad))
                print(f"Calculated position: ({x}, {y}) from range {range_km}km and bearing {contact['bearing']}°")
            else:
                x = float(contact['x'])
                y = float(contact['y'])
                print(f"Using provided position: ({x}, {y})")
            
            print(f"Drawing oval at ({x-uncertainty_radius}, {y-uncertainty_radius}, {x+uncertainty_radius}, {y+uncertainty_radius})")
            # Draw main uncertainty circle
            oval_id = self.map_canvas.create_oval(
                x - uncertainty_radius,
                y - uncertainty_radius,
                x + uncertainty_radius,
                y + uncertainty_radius,
                outline=base_color,
                dash=(2, 2),
                tags="contact_uncertainty"
            )
            print(f"Created oval with ID {oval_id}")
            
            # Draw inner circle for FIRM solutions
            if contact['solution'] == 'FIRM':
                inner_radius = uncertainty_radius * 0.5
                inner_id = self.map_canvas.create_oval(
                    x - inner_radius,
                    y - inner_radius,
                    x + inner_radius,
                    y + inner_radius,
                    outline=base_color,
                    dash=(2, 2),
                    tags="contact_uncertainty"
                )
                print(f"Created inner oval with ID {inner_id}")
                
        except (ValueError, KeyError, TypeError) as e:
            print(f"Error drawing uncertainty for contact: {e}")
            print(f"Contact data: {contact}")
            
    def _draw_contact_labels(self, x, y, radius, contact):
        """Draw labels for a contact."""
        layer_color = self._get_layer_color(contact['layer'])
        
        # Layer indicator
        self.map_canvas.create_text(
            x + radius + 5,
            y - 10,
            text=contact['layer'],
            fill=layer_color,
            font=('Arial', 8),
            anchor="w",
            tags="contact_label"
        )
        
        # Range and bearing
        self.map_canvas.create_text(
            x + radius + 5,
            y + 5,
            text=f"{contact['range']}km / {float(contact['bearing']):.0f}°",
            fill=self._get_contact_color(contact['solution']),
            font=('Arial', 8),
            anchor="w",
            tags="contact_label"
        )
            
    def _draw_uncertainty_circle(self, x, y, radius, color):
        """Draw uncertainty circle for a contact."""
        self.map_canvas.create_oval(
            x - radius, y - radius,
            x + radius, y + radius,
            outline=color,
            dash=(2, 2),
            tags="contact_uncertainty"
        )
        
        if color == self._get_contact_color('FIRM'):
            inner_radius = radius * 0.5
            self.map_canvas.create_oval(
                x - inner_radius,
                y - inner_radius,
                x + inner_radius,
                y + inner_radius,
                outline=color,
                dash=(2, 2),
                tags="contact_uncertainty"
            )

    def _draw_layer_indicator(self, contact):
        """Draw thermal layer indicator next to contact."""
        x = contact['x']
        y = contact['y']
        layer = contact['layer']
        
        # Create layer indicator text
        self.map_canvas.create_text(
            x + 30,  # Offset from contact
            y - 15,
            text=layer,
            fill=self._get_layer_color(layer),
            font=('Arial', 8),
            tags="layer_indicator"
        )
        
    def draw_torpedo(self, torpedo, friendly):
        """Draw a torpedo on the map."""
        size = torpedo.size
        color = 'lime' if friendly else 'red'
        wake_color = '#90EE90' if friendly else '#FFB6C6'
        
        # Draw torpedo body
        heading_rad = math.radians(torpedo.heading)
        dx = math.sin(heading_rad) * size * 2
        dy = -math.cos(heading_rad) * size * 2
        
        # Create torpedo with glowing effect
        self.map_canvas.create_oval(
            torpedo.x - size, torpedo.y - size,
            torpedo.x + size, torpedo.y + size,
            fill=color,
            outline='white',
            width=1,
            tags="weapon"
        )
        
        self.map_canvas.create_line(
            torpedo.x - dx, torpedo.y - dy,
            torpedo.x + dx, torpedo.y + dy,
            fill=color,
            width=3,
            tags="weapon"
        )
        
        # Draw torpedo wake
        if len(torpedo.track_history) > 1:
            points = []
            for x, y in torpedo.track_history:
                points.extend([x, y])
            if points:
                self.map_canvas.create_line(
                    points,
                    fill=wake_color,
                    width=2,
                    tags="wake"
                )
    
    def _get_layer_color(self, layer):
        """Get color for thermal layer indication."""
        return {
            'SURFACE': '#4a90e2',      # Blue
            'THERMOCLINE': '#2ecc71',  # Green
            'DEEP': '#8e44ad'          # Purple
        }.get(layer, 'white')
                
    def update_contact_display(self):
        """Update enhanced contact display with uncertainty circles."""
        # Clear previous contact overlays
        self.map_canvas.delete("contact")
        self.map_canvas.delete("contact_uncertainty")
        self.map_canvas.delete("contact_label")
        
        # Get valid contacts from simulator
        valid_contacts = self.sim.get_valid_contacts()
        
        for contact in valid_contacts:
            # Calculate uncertainty radius based on multiple factors
            uncertainty_radius = self._get_uncertainty_radius(contact)
            
            # Get base color from solution quality
            solution_color = self._get_contact_color(contact['solution'])
            
            try:
                # Calculate position in map coordinates
                if 'x' not in contact or 'y' not in contact:
                    range_km = float(contact['range'])
                    bearing_rad = math.radians(float(contact['bearing']))
                    x = self.sim.x_position + (range_km * 25 * math.sin(bearing_rad))
                    y = self.sim.y_position - (range_km * 25 * math.cos(bearing_rad))
                else:
                    x = float(contact['x'])
                    y = float(contact['y'])
                
                # Draw main uncertainty circle
                self.map_canvas.create_oval(
                    x - uncertainty_radius,
                    y - uncertainty_radius,
                    x + uncertainty_radius,
                    y + uncertainty_radius,
                    outline=solution_color,
                    dash=(2, 2),
                    tags="contact_uncertainty"
                )
                
                # Draw inner circle for FIRM solutions
                if contact['solution'] == 'FIRM':
                    inner_radius = uncertainty_radius * 0.5
                    self.map_canvas.create_oval(
                        x - inner_radius,
                        y - inner_radius,
                        x + inner_radius,
                        y + inner_radius,
                        outline=solution_color,
                        dash=(2, 2),
                        tags="contact_uncertainty"
                    )
                
                # Add contact labels
                layer_color = self._get_layer_color(contact['layer'])
                self.map_canvas.create_text(
                    x + uncertainty_radius + 5,
                    y - 10,
                    text=contact['layer'],
                    fill=layer_color,
                    font=('Arial', 8),
                    anchor="w",
                    tags="contact_label"
                )
                
                self.map_canvas.create_text(
                    x + uncertainty_radius + 5,
                    y + 5,
                    text=f"{contact['range']}km / {contact['bearing']:.0f}°",
                    fill=solution_color,
                    font=('Arial', 8),
                    anchor="w",
                    tags="contact_label"
                )
                
            except (ValueError, KeyError) as e:
                if 'x' in contact and 'y' in contact:
                    print(f"Error processing contact at ({contact['x']}, {contact['y']})")
                else:
                    print(f"Error processing contact at range {contact.get('range', 'unknown')}")
            
    def create_layer_status_panel(self):
        """Create thermal layer status panel."""
        layer_frame = ttk.LabelFrame(self.control_frame, text="Thermal Layer")
        layer_frame.grid(row=0, column=5, padx=15, pady=5, sticky="ne")
        
        # Create layer indicators
        self.layer_indicators = {}
        layers = ['SURFACE', 'THERMOCLINE', 'DEEP']
        
        for i, layer in enumerate(layers):
            frame = ttk.Frame(layer_frame)
            frame.pack(fill="x", pady=2)
            
            indicator = ttk.Label(
                frame,
                text="○",  # Will be updated to "●" when active
                font=('Arial', 10, 'bold'),
                foreground=self._get_layer_color(layer)
            )
            indicator.pack(side="left", padx=5)
            
            label = ttk.Label(frame, text=layer)
            label.pack(side="left", padx=5)
            
            self.layer_indicators[layer] = indicator
    
    def update_layer_status(self, current_layer):
        """Update thermal layer status indicators."""
        for layer, indicator in self.layer_indicators.items():
            if layer == current_layer:
                indicator.configure(text="●")
            else:
                indicator.configure(text="○")

    def setup_gui(self):
        """Create all GUI elements with enhanced sonar display."""
        self.create_frames()
        self.create_control_panel()
        self.create_visualization()
        self.create_compass_view()
        self.create_map_view()
        self.create_info_panels()
        
        # Add new thermal layer status panel
        self.create_layer_status_panel()

    def create_frames(self):
        """Create main frame structure with optimized layout"""
        # Top control bar frame
        self.control_frame = ttk.Frame(self.root, padding="5")
        self.control_frame.grid(row=0, column=0, columnspan=4, sticky="ew")
                
        # Main view frame for map and side view - FIXED HEIGHT
        self.view_frame = ttk.Frame(self.root, padding="5", height=800)
        self.view_frame.grid(row=1, column=0, columnspan=4, sticky="nsew")
        self.view_frame.grid_propagate(False)  # Prevent resizing
                
        # Configure grid weights for better space utilization
        self.root.grid_rowconfigure(1, weight=1)
        self.root.grid_columnconfigure(1, weight=3)  # Give more weight to map column
        
        # Force the view frame to maintain its size
        self.view_frame.configure(width=1200)
        
        # Configure the view frame's internal grid
        self.view_frame.grid_rowconfigure(0, weight=1)
        self.view_frame.grid_columnconfigure(0, minsize=300)  # Side view width
        self.view_frame.grid_columnconfigure(1, weight=1)     # Map gets remaining space

    def create_control_panel(self):
        """Create all submarine control elements with enhanced tick marks"""
        control_frame = ttk.LabelFrame(self.control_frame, text="Submarine Controls", padding="10")
        control_frame.grid(row=0, column=0, columnspan=2, padx=10, pady=5, sticky="ew")
        
        controls_left = ttk.Frame(control_frame)
        controls_left.grid(row=0, column=0, padx=5, sticky="nsw")
        
        # Create canvas for tick marks - reduced height
        self.depth_ticks = tk.Canvas(controls_left, width=200, height=5, bg='white')
        self.speed_ticks = tk.Canvas(controls_left, width=200, height=5, bg='white')
        self.heading_ticks = tk.Canvas(controls_left, width=200, height=5, bg='white')
        
        # Add depth slider with tick marks
        ttk.Label(controls_left, text="Depth:").grid(row=0, column=0, padx=5, pady=5)
        ttk.Label(controls_left, textvariable=self.depth_var).grid(row=0, column=1, padx=5, pady=5)
        
        ttk.Label(controls_left, text="SURFACE",
                 font=('Arial', 8, 'bold')).grid(row=0, column=2, padx=5, pady=5)
        
        self.depth_ticks.grid(row=0, column=3, padx=5, pady=(0, 0))
        self.draw_tick_marks(self.depth_ticks, [0, 125, 250, 375, 500])  # 0%, 25%, 50%, 75%, 100%
        
        self.depth_slider = ttk.Scale(
            controls_left,
            from_=0,
            to=500,
            orient='horizontal',
            length=200,
            command=self.sim.on_depth_slide
        )
        self.depth_slider.grid(row=1, column=3, padx=5, pady=(0, 5))
        
        ttk.Label(controls_left, text="DIVE",
                 font=('Arial', 8, 'bold')).grid(row=0, column=4, padx=5, pady=5)
        
        self.depth_risk_label = ttk.Label(
            controls_left,
            text="SAFE DEPTH",
            font=('Arial', 8),
            foreground='green'
        )
        self.depth_risk_label.grid(row=0, column=5, padx=5, pady=5)
        
        # Add speed slider with tick marks
        ttk.Label(controls_left, text="Speed:").grid(row=2, column=0, padx=5, pady=5)
        ttk.Label(controls_left, textvariable=self.speed_var).grid(row=2, column=1, padx=5, pady=5)
        
        ttk.Label(controls_left, text="MIN",
                 font=('Arial', 8, 'bold')).grid(row=2, column=2, padx=5, pady=5)
        
        self.speed_ticks.grid(row=2, column=3, padx=5, pady=(0, 0))
        self.draw_tick_marks(self.speed_ticks, [0, 7.5, 15, 22.5, 30])  # 0%, 25%, 50%, 75%, 100%
        
        self.speed_slider = ttk.Scale(
            controls_left,
            from_=0,
            to=30,
            orient='horizontal',
            length=200,
            command=self.sim.on_speed_slide
        )
        self.speed_slider.grid(row=3, column=3, padx=5, pady=(0, 5))
        
        ttk.Label(controls_left, text="MAX",
                 font=('Arial', 8, 'bold')).grid(row=2, column=4, padx=5, pady=5)
        
        self.cavitation_label = ttk.Label(
            controls_left,
            text="",
            font=('Arial', 8),
            foreground='gray'
        )
        self.cavitation_label.grid(row=2, column=5, padx=5, pady=5)
        
        # Add heading slider with tick marks
        ttk.Label(controls_left, text="Turn:").grid(row=4, column=0, padx=5, pady=5)
        ttk.Label(controls_left, textvariable=self.heading_var).grid(row=4, column=1, padx=5, pady=5)
        
        ttk.Label(controls_left, text="LEFT",
                 font=('Arial', 8, 'bold')).grid(row=4, column=2, padx=5, pady=5)
        
        self.heading_ticks.grid(row=4, column=3, padx=5, pady=(0, 0))
        self.draw_tick_marks(self.heading_ticks, [0, 90, 180, 270, 359])  # Major compass points
        
        self.heading_slider = ttk.Scale(
            controls_left,
            from_=0,
            to=359,
            orient='horizontal',
            length=200,
            command=self.sim.on_heading_slide
        )
        self.heading_slider.grid(row=5, column=3, padx=5, pady=(0, 5))
        
        ttk.Label(controls_left, text="RIGHT",
                 font=('Arial', 8, 'bold')).grid(row=4, column=4, padx=5, pady=5)

        # Add torpedo control frame
        torpedo_frame = ttk.Frame(control_frame)
        torpedo_frame.grid(row=0, column=1, padx=20, sticky="ne")
        
        self.torpedo_button = ttk.Button(
            torpedo_frame,
            text="Launch Torpedo!",
            command=self.sim.fire_torpedo
        )
        self.torpedo_button.grid(row=0, column=0, padx=5, pady=5)
        
        ttk.Label(torpedo_frame, text="**Mark 48 ADCAP (US Navy)",
                 font=('Arial', 8)).grid(row=0, column=1, padx=5, pady=5)
        
    def _get_uncertainty_radius(self, contact):
        """Calculate display radius based on multiple factors."""
        # Base radius in map units
        base_radius = 25
        
        # Get scaling factors
        range_factor = self._get_range_uncertainty(contact)
        solution_factor = self._get_solution_factor(contact['solution'])
        layer_factor = self._get_layer_uncertainty_factor(contact)
        speed_factor = self._get_speed_uncertainty_factor(contact)
        
        # Combine all factors
        final_radius = base_radius * range_factor * solution_factor * layer_factor * speed_factor
        
        # Ensure minimum and maximum reasonable sizes
        return max(15, min(final_radius, 150))
    
    def _get_range_uncertainty(self, contact):
        """Calculate uncertainty factor based on range."""
        try:
            range_km = float(contact['range'])
        except (ValueError, KeyError):
            return 1.0
            
        # Uncertainty increases with range
        # 1.0 at 0km, 2.0 at 20km, 3.0 at 40km
        range_factor = 1.0 + (range_km / 20.0)
        return min(3.0, range_factor)
    
    def _get_layer_uncertainty_factor(self, contact):
        """Calculate uncertainty factor based on thermal layer."""
        try:
            contact_layer = contact['layer']
            player_layer = self.sim.get_thermal_layer_status(self.sim.depth)
        except (KeyError, AttributeError):
            return 1.5
        
        # Same layer has less uncertainty
        if contact_layer == player_layer:
            return 1.0
            
        # Layer transitions increase uncertainty
        if 'THERMOCLINE' in (contact_layer, player_layer):
            return 2.0
            
        # Surface to deep has highest uncertainty
        return 2.5
    
    def _get_speed_uncertainty_factor(self, contact):
        """Calculate uncertainty factor based on relative speed."""
        try:
            contact_speed = float(contact['speed'])
            player_speed = self.sim.speed
        except (ValueError, KeyError):
            return 1.0
            
        # Higher speeds increase uncertainty
        relative_speed = abs(contact_speed - player_speed)
        speed_factor = 1.0 + (relative_speed / 20.0)
        return min(2.0, speed_factor)
    
    def _get_solution_factor(self, solution):
        """Get scaling factor based on solution quality."""
        return {
            'FIRM': 1.0,
            'WEAK': 1.5,
            'UNCERTAIN': 2.0
        }.get(solution, 2.0)
    
    def _get_contact_color(self, solution):
        """Get color based on solution quality."""
        return {
            'FIRM': '#00ff00',     # Bright green
            'WEAK': '#ffff00',     # Yellow
            'UNCERTAIN': '#ff0000'  # Red
        }.get(solution, '#808080')  # Gray as fallback
    
    def _get_layer_color(self, layer):
        """Get color for thermal layer indication."""
        return {
            'SURFACE': '#4a90e2',     # Blue
            'THERMOCLINE': '#2ecc71',  # Green
            'DEEP': '#8e44ad'         # Purple
        }.get(layer, '#ffffff')       # White as fallback

    def create_visualization(self):
        """Create the side view visualization with thermal layers"""
        self.side_canvas = tk.Canvas(self.view_frame, width=300, height=600, bg='#1a1a1a')
        self.side_canvas.grid(row=0, column=0, padx=10, pady=5, sticky="nsew")
        
        # Draw thermal layers
        self.draw_thermal_layers()
        
        # Draw depth markers
        self.draw_depth_markers()
        
        # Create submarine shape
        self.sub_shape = self.create_submarine(150, 200)
        
    def draw_tick_marks(self, canvas, values):
        """Draw simple tick marks on a canvas for slider reference points."""
        canvas.delete('all')
        
        # Draw major tick marks
        for value in values:
            # Calculate x position based on value range
            x = (value - values[0]) * 200 / (values[-1] - values[0])
            # Draw tick mark - just a simple line
            canvas.create_line(x, 0, x, 5, fill='black', width=1)
            
    def draw_scrollbar_ticks(self, canvas, orientation):
        """Draw simple tick marks for scrollbars."""
        canvas.delete('all')
        
        if orientation == 'horizontal':
            width = canvas.winfo_width() or 1200  # Fallback if not yet realized
            # Draw tick marks at 25% intervals
            for i in range(5):  # 0%, 25%, 50%, 75%, 100%
                x = width * (i / 4)
                canvas.create_line(x, 0, x, 5, fill='black', width=1)
        else:  # vertical
            height = canvas.winfo_height() or 800  # Fallback if not yet realized
            # Draw tick marks at 25% intervals
            for i in range(5):  # 0%, 25%, 50%, 75%, 100%
                y = height * (i / 4)
                canvas.create_line(20, y, 25, y, fill='black', width=1)
        
    def create_map_view(self):
        """Create the top-down map view with fixed dimensions."""
        # Create main container frame with fixed dimensions
        self.map_frame = ttk.Frame(self.view_frame)
        self.map_frame.grid(row=0, column=1, rowspan=2, padx=10, pady=5, sticky="nsew")
        self.map_frame.grid_propagate(False)  # Prevent automatic resizing
        
        # Force the map frame to maintain its size
        self.map_frame.configure(width=1200, height=800)
        
        # Create canvas container to properly manage scrollbars
        canvas_container = ttk.Frame(self.map_frame)
        canvas_container.grid(row=0, column=0, sticky="nsew")
        canvas_container.grid_propagate(False)
        
        # Set up the canvas with fixed viewport size
        self.map_canvas = tk.Canvas(
            canvas_container,
            width=1200,
            height=750,  # Leave room for horizontal scrollbar
            bg='#E6F3FF'
        )
        
        # Create scrollbars
        h_scrollbar = ttk.Scrollbar(self.map_frame, orient="horizontal", command=self.map_canvas.xview)
        v_scrollbar = ttk.Scrollbar(canvas_container, orient="vertical", command=self.map_canvas.yview)
        
        # Configure canvas scrolling
        self.map_canvas.configure(
            xscrollcommand=h_scrollbar.set,
            yscrollcommand=v_scrollbar.set,
            scrollregion=(0, 0, 4500, 4500)
        )
        
        # Set up scaling transformation
        self.scale_factor = 0.5
        
        # Grid layout with proper weights
        self.map_canvas.grid(row=0, column=0, sticky="nsew")
        h_scrollbar.grid(row=1, column=0, sticky="ew")
        v_scrollbar.grid(row=0, column=1, sticky="ns")
        
        # Configure weight distribution
        canvas_container.grid_rowconfigure(0, weight=1)
        canvas_container.grid_columnconfigure(0, weight=1)
        self.map_frame.grid_rowconfigure(0, weight=1)
        self.map_frame.grid_columnconfigure(0, weight=1)
        
        # Draw grid and create submarine at its current position
        self.draw_map_grid()
        self.map_sub = self.create_map_submarine(self.sim.x_position, self.sim.y_position)
        
        # Center the view on the submarine's initial position with a slight delay
        # to ensure canvas is ready
        self.root.after(100, self.center_initial_view)
        
    def create_compass_view(self):
        """Create the compass view in the top control panel"""
        compass_frame = ttk.Frame(self.control_frame)
        compass_frame.grid(row=0, column=1, padx=15, pady=5, sticky="ne")
        
        self.compass_canvas = tk.Canvas(compass_frame, width=150, height=150, bg='white')
        self.compass_canvas.pack(padx=5, pady=5)
        
        self.draw_compass_rose(75, 75, 60)
        self.compass_sub = self.create_compass_submarine(75, 75)

    def animate_explosion(self, x, y):
        """Create explosion animation at specified coordinates"""
        colors = ['yellow', 'orange', 'red', 'gray']
        sizes = [10, 20, 30, 40, 30, 20, 10]
        explosions = []
        
        def animate_frame(frame):
            # Clear previous frame
            for exp in explosions:
                self.map_canvas.delete(exp)
            explosions.clear()
            
            if frame < len(sizes):
                size = sizes[frame]
                color = colors[min(frame, len(colors)-1)]
                
                # Create explosion circle
                exp = self.map_canvas.create_oval(
                    x - size, y - size,
                    x + size, y + size,
                    fill=color, outline=color
                )
                explosions.append(exp)
                
                # Schedule next frame
                self.root.after(100, lambda: animate_frame(frame + 1))
            else:
                # Clean up explosions list when animation is complete
                self.active_explosions = [e for e in self.active_explosions if e not in explosions]
        
        # Start animation
        animate_frame(0)
        
        # Track this explosion
        self.active_explosions.extend(explosions)

    def draw_thermal_layers(self):
        """Draw thermal layer visualization"""
        scale_factor = 0.9  # Match the submarine movement scale
        
        # Surface mixed layer (0-50m)
        y1 = 50
        y2 = 50 + (50 * scale_factor)
        self.side_canvas.create_rectangle(0, y1, 300, y2, 
                                        fill='#a8d5e5', width=0)
        
        # Transition zone (50-80m)
        y1 = y2
        y2 = 50 + (80 * scale_factor)
        self.side_canvas.create_rectangle(0, y1, 300, y2,
                                        fill='#8abfd4', width=0)
        
        # Thermocline (80-200m)
        y1 = y2
        y2 = 50 + (200 * scale_factor)
        self.side_canvas.create_rectangle(0, y1, 300, y2, 
                                        fill='#68a4bf', width=0)
        
        # Deep water (>200m)
        y1 = y2
        y2 = 50 + (500 * scale_factor)
        self.side_canvas.create_rectangle(0, y1, 300, y2, 
                                        fill='#2c5a7c', width=0)
        
        # Add layer labels
        self.side_canvas.create_text(290, 50 + (25 * scale_factor), 
                                   text="Mixed Layer",
                                   anchor="e", fill='black', font=('Arial', 7))
        self.side_canvas.create_text(290, 50 + (140 * scale_factor), 
                                   text="Thermocline",
                                   anchor="e", fill='navy', font=('Arial', 7))
        self.side_canvas.create_text(290, 50 + (350 * scale_factor), 
                                   text="Deep Water",
                                   anchor="e", fill='white', font=('Arial', 7))

    def draw_depth_markers(self):
        """Draw depth markers with thermal layer indicators"""
        scale_factor = 0.9  # Match the submarine movement scale
        
        for depth in range(0, 501, 50):
            y = 50 + (depth * scale_factor)
            color = 'white'  # Default color
            note = ""
            
            # Determine color and note based on depth
            if depth <= 50:
                note = "Mixed Layer"
                color = 'black'
            elif 80 <= depth <= 200:
                note = "Thermocline"
                color = 'navy'
            elif depth > 200:
                color = 'white'
                
            if depth >= 300:
                color = '#ffd700'  # Gold color for warning zone
            if depth >= 450:
                color = '#ff8c00'  # Dark orange for danger zone
                
            # Draw marker line
            self.side_canvas.create_line(0, y, 20, y, fill=color, width=1)
            
            # Draw depth label
            self.side_canvas.create_text(25, y, text=f"{depth}m", 
                                       anchor="w", fill=color, 
                                       font=('Arial', 8))
            
            # Add note if present
            if note:
                self.side_canvas.create_text(80, y, text=note, 
                                           anchor="w", fill=color, 
                                           font=('Arial', 7))

    def draw_map_grid(self):
        """Draw navigation grid with scaled coordinate system."""
        # Grid spacing is now 25 pixels (half of original 50) to show more area
        grid_size = 25

        # Draw vertical lines
        for x in range(0, 9001, grid_size):
            # Make every 10th line darker (equivalent to original every 5th)
            color = '#666666' if x % (grid_size * 10) == 0 else '#CCCCCC'
            width = 1 if x % (grid_size * 10) != 0 else 2
            self.map_canvas.create_line(x, 0, x, 9000, fill=color, width=width, tags="grid")

        # Draw horizontal lines
        for y in range(0, 9001, grid_size):
            color = '#666666' if y % (grid_size * 10) == 0 else '#CCCCCC'
            width = 1 if y % (grid_size * 10) != 0 else 2
            self.map_canvas.create_line(0, y, 9000, y, fill=color, width=width, tags="grid")

        # Add coordinate labels on edges (adjust position for new scale)
        for x in range(0, 9001, grid_size * 10):
            self.map_canvas.create_text(
                x, 15,
                text=f"{x//25}",  # Adjust for new scale
                fill='#444444',
                font=('Arial', 8),
                tags="grid"
            )

        for y in range(0, 9001, grid_size * 10):
            self.map_canvas.create_text(
                15, y,
                text=f"{y//25}",  # Adjust for new scale
                fill='#444444',
                font=('Arial', 8),
                tags="grid"
            )
            
    def draw_surface_vessels(self):
        """Draw surface ships and submarines with proper detection rules."""
        # Always show vessels if we're surfaced (depth <= 10m)
        if self.sim.depth <= 10:
            for ship in self.sim.ships:
                if ship.is_active:
                    self.draw_ship(ship)
            
            for sub in self.sim.enemy_submarines:
                if sub.is_active:
                    self.draw_enemy_submarine(sub)
        else:
            # When submerged, only draw vessels that are detected
            valid_contacts = self.sim.get_valid_contacts()
            
            # Create lookup of detected vessels by coordinates for quick checking
            detected_positions = {
                (contact.get('x', None), contact.get('y', None)): contact
                for contact in valid_contacts
            }
            
            # Draw surface ships only if detected
            for ship in self.sim.ships:
                if ship.is_active:
                    if (ship.x, ship.y) in detected_positions:
                        contact = detected_positions[(ship.x, ship.y)]
                        # Draw with different visibility based on solution quality
                        if contact['solution'] == 'FIRM':
                            self.draw_ship(ship)
                        else:
                            self.draw_uncertain_contact(ship, contact['solution'])
            
            # Draw enemy submarines only if detected
            for sub in self.sim.enemy_submarines:
                if sub.is_active:
                    if (sub.x, sub.y) in detected_positions:
                        contact = detected_positions[(sub.x, sub.y)]
                        if contact['solution'] == 'FIRM':
                            self.draw_enemy_submarine(sub)
                        else:
                            self.draw_uncertain_contact(sub, contact['solution'])
        
        # Ensure proper z-order
        self.map_canvas.tag_raise("wake")
        self.map_canvas.tag_raise("ship")
        self.map_canvas.tag_raise("weapon")
        self.map_canvas.tag_raise("player_sub")
        
    def draw_uncertain_contact(self, vessel, solution_quality):
        """Draw a vessel contact with uncertainty indication."""
        # Determine color based on solution quality
        color = '#ffff00' if solution_quality == 'WEAK' else '#ff0000'  # Yellow for WEAK, Red for UNCERTAIN
        
        # Draw uncertainty circle
        uncertainty_radius = 30 if solution_quality == 'WEAK' else 50
        self.map_canvas.create_oval(
            vessel.x - uncertainty_radius,
            vessel.y - uncertainty_radius,
            vessel.x + uncertainty_radius,
            vessel.y + uncertainty_radius,
            outline=color,
            dash=(2, 4),
            tags="ship"
        )
        
        # Draw center point
        self.map_canvas.create_oval(
            vessel.x - 3,
            vessel.y - 3,
            vessel.x + 3,
            vessel.y + 3,
            fill=color,
            outline=color,
            tags="ship"
        )

    def update_display_values(self, depth, speed, heading):
        """Update all display values"""
        self.depth_var.set(f"{depth:.1f}m")
        self.speed_var.set(f"{speed:.1f} knots")
        self.heading_var.set(f"{heading:.1f}°")
        self.update_stealth_indicators(time.time())

    # REPLACE the entire update_submarine_position method in SubmarineGUI class:
    def update_submarine_position(self):
        """Update submarine position in side view with corrected visibility."""
        if self.sub_shape:
            # Calculate target Y position with corrected scale factor
            target_y = 50 + (self.sim.depth * 0.9)
            current_coords = self.side_canvas.coords(self.sub_shape)
            
            if current_coords:
                current_y = sum(current_coords[1::2]) / (len(current_coords) / 2)
                
                # Smooth interpolation
                lerp_factor = 0.15
                new_y = current_y + (target_y - current_y) * lerp_factor
                
                # Calculate movement delta
                delta_y = new_y - current_y
                
                # Move submarine shape
                self.side_canvas.move(self.sub_shape, 0, delta_y)
                
                # Ensure submarine remains visible
                self.side_canvas.tag_raise(self.sub_shape)
            
    def update_compass_view(self):
        """Update compass view with current heading"""
        if self.compass_sub:
            center_x, center_y = 75, 75
            self.compass_canvas.delete(self.compass_sub)
            
            # Create new submarine shape at current heading
            angle = math.radians(self.sim.heading - 90)
            length = 25
            width = 10
            
            # Calculate rotated points
            points = []
            base_points = [
                (-length//2, 0),
                (-length//4, -width//2),
                (length//3, -width//2),
                (length//2, 0),
                (length//3, width//2),
                (-length//4, width//2)
            ]
            
            for x, y in base_points:
                rot_x = x * math.cos(angle) - y * math.sin(angle)
                rot_y = x * math.sin(angle) + y * math.cos(angle)
                points.extend([center_x + rot_x, center_y + rot_y])
            
            self.compass_sub = self.compass_canvas.create_polygon(
                points, fill='gray', outline='black'
            )

    def update_map_position(self):
        """Update submarine and vessel positions on map."""
        current_time = time.time()
        
        # Clear previous drawings
        self.map_canvas.delete("ship")
        self.map_canvas.delete("wake")
        self.map_canvas.delete("weapon")
        self.map_canvas.delete("player_sub")
        
        # Draw elements in correct order
        self.draw_wake_trails()
        self.draw_weapons()
        self.draw_surface_vessels()
        
        # Update player submarine position
        if self.map_sub:
            self.map_canvas.delete(self.map_sub)
        self.map_sub = self.create_map_submarine(
            self.sim.x_position,
            self.sim.y_position
        )
        
        # Handle map centering
        if current_time - self.last_center_time >= self.center_cooldown:
            self.check_sub_position()
            self.last_center_time = current_time
            
    def check_sub_position(self):
        """Check if submarine is near viewport edges."""
        # Get current visible area
        visible_left = self.map_canvas.canvasx(0)
        visible_right = self.map_canvas.canvasx(self.map_canvas.winfo_width())
        visible_top = self.map_canvas.canvasy(0)
        visible_bottom = self.map_canvas.canvasy(self.map_canvas.winfo_height())
        
        # Calculate margins (15% of viewport size)
        margin_x = self.map_canvas.winfo_width() * 0.15
        margin_y = self.map_canvas.winfo_height() * 0.15
        
        # Get scaled submarine position
        sub_x = self.sim.x_position * self.scale_factor
        sub_y = self.sim.y_position * self.scale_factor
        
        # Check if submarine is near edges
        need_center_x = sub_x < visible_left + margin_x or sub_x > visible_right - margin_x
        need_center_y = sub_y < visible_top + margin_y or sub_y > visible_bottom - margin_y
        
        if need_center_x or need_center_y:
            self.center_view_on_submarine()
            
    def center_view_on_submarine(self):
        """Center the map view on submarine's current position."""
        # Get viewport dimensions
        viewport_width = self.map_canvas.winfo_width()
        viewport_height = self.map_canvas.winfo_height()
        
        # Get scaled submarine position
        sub_x = self.sim.x_position * self.scale_factor
        sub_y = self.sim.y_position * self.scale_factor
        
        # Calculate scroll fractions to center the submarine
        scroll_x = (sub_x - viewport_width/2) / (4500 * self.scale_factor)
        scroll_y = (sub_y - viewport_height/2) / (4500 * self.scale_factor)
        
        # Ensure scroll values are within bounds (0 to 1)
        scroll_x = max(0, min(1, scroll_x))
        scroll_y = max(0, min(1, scroll_y))
        
        # Move the view
        self.map_canvas.xview_moveto(scroll_x)
        self.map_canvas.yview_moveto(scroll_y)

    def draw_wake_trails(self):
        """Draw wake trails for detected vessels."""
        # If we're surfaced, draw all wakes
        if self.sim.depth <= 10:
            # Draw player submarine wake
            if len(self.sim.track_history) > 1:
                points = []
                for x, y in self.sim.track_history:
                    points.extend([x, y])
                if points:
                    self.map_canvas.create_line(
                        points,
                        fill='gray',
                        width=1,
                        tags="wake"
                    )
            
            # Draw all ship wakes
            for ship in self.sim.ships:
                if ship.is_active and len(ship.track_history) > 1:
                    points = []
                    for x, y in ship.track_history:
                        points.extend([x, y])
                    if points:
                        self.map_canvas.create_line(
                            points,
                            fill='lightblue',
                            width=1,
                            tags="wake"
                        )
            
            # Draw all submarine wakes
            for sub in self.sim.enemy_submarines:
                if sub.is_active and len(sub.track_history) > 1:
                    points = []
                    for x, y in sub.track_history:
                        points.extend([x, y])
                    if points:
                        self.map_canvas.create_line(
                            points,
                            fill='red',
                            width=1,
                            tags="wake"
                        )
        else:
            # When submerged, only draw wakes for detected vessels
            valid_contacts = self.sim.get_valid_contacts()
            detected_positions = {
                (contact.get('x', None), contact.get('y', None)): contact
                for contact in valid_contacts
            }
            
            # Always draw player submarine wake
            if len(self.sim.track_history) > 1:
                points = []
                for x, y in self.sim.track_history:
                    points.extend([x, y])
                if points:
                    self.map_canvas.create_line(
                        points,
                        fill='gray',
                        width=1,
                        tags="wake"
                    )
            
            # Draw ship wakes only if detected
            for ship in self.sim.ships:
                if ship.is_active and (ship.x, ship.y) in detected_positions:
                    if len(ship.track_history) > 1:
                        points = []
                        for x, y in ship.track_history:
                            points.extend([x, y])
                        if points:
                            self.map_canvas.create_line(
                                points,
                                fill='lightblue',
                                width=1,
                                tags="wake"
                            )
            
            # Draw submarine wakes only if detected
            for sub in self.sim.enemy_submarines:
                if sub.is_active and (sub.x, sub.y) in detected_positions:
                    if len(sub.track_history) > 1:
                        points = []
                        for x, y in sub.track_history:
                            points.extend([x, y])
                        if points:
                            self.map_canvas.create_line(
                                points,
                                fill='red',
                                width=1,
                                tags="wake"
                            )

    def draw_weapons(self):
        """Draw all active weapons with correct visibility."""
        # Draw player torpedoes
        for torpedo in self.sim.torpedoes:
            if torpedo.is_active:
                self.draw_torpedo(torpedo, True)
        
        # Draw enemy torpedoes
        for torpedo in self.sim.enemy_torpedoes:
            if torpedo.is_active:
                self.draw_torpedo(torpedo, False)
        
        # Draw enemy projectiles
        for projectile in self.sim.enemy_projectiles:
            if projectile.is_active:
                self.draw_projectile(projectile)

    def draw_projectile(self, projectile):
        """Draw a gun projectile on the map."""
        size = projectile.size * 1.5
        
        # Create glowing effect
        glow_size = size * 1.5
        self.map_canvas.create_oval(
            projectile.x - glow_size, projectile.y - glow_size,
            projectile.x + glow_size, projectile.y + glow_size,
            fill='#FFE87C',
            outline='',
            tags="weapon"
        )
        
        # Draw main projectile
        self.map_canvas.create_oval(
            projectile.x - size, projectile.y - size,
            projectile.x + size, projectile.y + size,
            fill='orange',
            outline='red',
            width=2,
            tags="weapon"
        )

    def draw_ship(self, ship):
        """Draw a ship on the map with improved visibility."""
        heading_rad = math.radians(ship.heading - 90)
        
        # Create points for ship shape
        length = ship.length
        width = ship.width
        
        bow_x = ship.x + math.cos(heading_rad) * length
        bow_y = ship.y + math.sin(heading_rad) * length
        
        stern_left_x = ship.x + math.cos(heading_rad + math.pi*0.9) * length * 0.7
        stern_left_y = ship.y + math.sin(heading_rad + math.pi*0.9) * length * 0.7
        
        stern_right_x = ship.x + math.cos(heading_rad - math.pi*0.9) * length * 0.7
        stern_right_y = ship.y + math.sin(heading_rad - math.pi*0.9) * length * 0.7
        
        # Set colors based on ship type
        ship_color = 'blue' if ship.ship_type == "merchant" else 'gray'
        outline_color = 'darkblue' if ship.ship_type == "merchant" else 'black'
        
        # Create ship polygon with improved visibility
        self.map_canvas.create_polygon(
            bow_x, bow_y,
            stern_left_x, stern_left_y,
            stern_right_x, stern_right_y,
            fill=ship_color,
            outline=outline_color,
            width=2,
            tags=("ship", "vessel")
        )

    def draw_enemy_submarine(self, sub):
        """Draw an enemy submarine with correct scaling."""
        # Scale submarine dimensions
        length = 18 * self.scale_factor
        width = 5 * self.scale_factor
        
        # Calculate scaled position
        x = sub.x * self.scale_factor
        y = sub.y * self.scale_factor
        
        heading_rad = math.radians(sub.heading - 90)
        
        points = [
            (-length/2, 0),           # Stern
            (-length/3, -width/2),    # Port side rear
            (length/4, -width/2),     # Port side forward
            (length/2, 0),            # Bow
            (length/4, width/2),      # Starboard side forward
            (-length/3, width/2),     # Starboard side rear
        ]
        
        rotated_points = []
        for px, py in points:
            rx = px * math.cos(heading_rad) - py * math.sin(heading_rad)
            ry = px * math.sin(heading_rad) + py * math.cos(heading_rad)
            rotated_points.extend([x + rx, y + ry])
        
        self.map_canvas.create_polygon(
            rotated_points,
            fill='red',
            outline='darkred',
            width=1,
            tags="ship"
        )

    def create_submarine(self, x, y):
        """Create submarine shape for side view"""
        points = [
            x - 25, y,
            x - 17, y - 7,
            x + 17, y - 7,
            x + 25, y,
            x + 17, y + 7,
            x - 17, y + 7,
        ]
        return self.side_canvas.create_polygon(points, fill='gray', outline='black', width=2)

    def create_map_submarine(self, x, y):
        """Create submarine shape for map view with improved visibility."""
        # Scale submarine dimensions - doubled size
        length = 40 * self.scale_factor  # Increased from 20
        width = 12 * self.scale_factor   # Increased from 6
        
        # Create base points for submarine
        points = [
            (-length/2, 0),           # Stern
            (-length/3, -width/2),    # Port side rear
            (length/4, -width/2),     # Port side forward
            (length/2, 0),            # Bow
            (length/4, width/2),      # Starboard side forward
            (-length/3, width/2),     # Starboard side rear
        ]
        
        # Get current heading in radians
        heading_rad = math.radians(self.sim.heading - 90)
        
        # Rotate and translate points
        rotated_points = []
        for px, py in points:
            rx = px * math.cos(heading_rad) - py * math.sin(heading_rad)
            ry = px * math.sin(heading_rad) + py * math.cos(heading_rad)
            rotated_points.extend([x + rx, y + ry])
        
        # Create polygon with rotated points and ensure visibility
        submarine = self.map_canvas.create_polygon(
            rotated_points,
            fill='darkgray',
            outline='black',
            width=2,
            tags=("player_sub", "vessel")
        )
        
        # Ensure submarine is on top
        self.map_canvas.tag_raise(submarine)
        
        return submarine

    # REPLACE the update_depth_warnings method:
    def update_depth_warnings(self, depth):
        """Update depth warning indicators with very low risk percentages"""
        if depth < self.sim.SAFE_DEPTH:
            self.depth_risk_label.configure(
                text="SAFE DEPTH",
                foreground='green'
            )
        else:
            # Calculate risk percentage for this depth
            depth_factor = (depth - self.sim.SAFE_DEPTH) / (495 - self.sim.SAFE_DEPTH)
            depth_factor = max(0, min(1, depth_factor))
            risk_percentage = (0.005 + (depth_factor * 0.045)) * 100  # 0.5% to 5%
            
            if depth < 400:
                self.depth_risk_label.configure(
                    text=f"HULL STRESS ({risk_percentage:.2f}% risk)",
                    foreground='yellow'
                )
            elif depth < 450:
                self.depth_risk_label.configure(
                    text=f"INCREASED PRESSURE ({risk_percentage:.2f}% risk)",
                    foreground='orange'
                )
            else:
                self.depth_risk_label.configure(
                    text=f"CRITICAL DEPTH ({risk_percentage:.2f}% risk)",
                    foreground='red'
                )

    def update_torpedo_button_state(self, time_since_last, reload_time):
        """Update torpedo button state"""
        if time_since_last < reload_time:
            self.torpedo_button.configure(state='disabled')
            remaining = reload_time - time_since_last
            self.torpedo_button.configure(text=f"Reloading... ({remaining:.1f}s)")
        else:
            self.torpedo_button.configure(state='normal')
            self.torpedo_button.configure(text="Launch Torpedo!")

    def update_stealth_indicators(self, current_time):
        """Update stealth-related indicators"""
        if hasattr(self, 'cavitation_label'):
            if self.sim.speed > self.sim.submarine_physics.cavitation_speed:
                self.cavitation_label.configure(
                    text="CAVITATION WARNING",
                    foreground='red'
                )
            else:
                self.cavitation_label.configure(
                    text="",
                    foreground='gray'
                )

    def get_thermal_layer(self, depth):
        """Get thermal layer description based on depth."""
        if depth <= 50:
            return "SURFACE"
        elif 80 <= depth <= 200:
            return "THERMOCLINE"
        else:
            return "DEEP"

    def create_info_panels(self):
        """Create reorganized information panels"""
        # Create stealth panel in top control frame
        self.stealth_panel = StealthPanel(self.control_frame)
        self.stealth_panel.frame.grid(row=0, column=2, padx=15, pady=5, sticky="ne")
        
        # Create combat stats panel in top control frame
        self.combat_stats = CombatStatsPanel(self.control_frame)
        self.combat_stats.frame.grid(row=0, column=3, padx=15, pady=5, sticky="ne")

    def update_sonar_contacts(self, ships, enemy_submarines, sub_x, sub_y, heading):
        """Update sonar contacts display with correct scaling."""
        # Get valid contacts within range
        valid_contacts = self.sim.get_valid_contacts()
        
        # Update contact tree display
        if hasattr(self, 'sonar_display'):
            self.sonar_display.update_contacts(valid_contacts)
        
        # Update map visualization
        self.update_contact_display()
        
        # Process surface ships with scaled coordinates
        for ship in ships:
            if not ship.is_active:
                continue
                
            dx = (ship.x * self.scale_factor) - (sub_x * self.scale_factor)
            dy = (ship.y * self.scale_factor) - (sub_y * self.scale_factor)
            distance = math.hypot(dx, dy)
            rel_bearing = (math.degrees(math.atan2(dx, -dy)) - heading) % 360
            
        # Process enemy submarines with scaled coordinates
        player_layer = self.sim.get_thermal_layer_status()
        for sub in enemy_submarines:
            if not sub.is_active:
                continue
                
            dx = (sub.x * self.scale_factor) - (sub_x * self.scale_factor)
            dy = (sub.y * self.scale_factor) - (sub_y * self.scale_factor)
            distance = math.hypot(dx, dy)
            rel_bearing = (math.degrees(math.atan2(dx, -dy)) - heading) % 360
            
            sub_layer = self.sim.get_thermal_layer_status(sub.depth)
            in_same_layer = (player_layer == sub_layer)

    def update_combat_stats(self, stats, hull_integrity):
        """Update combat statistics display"""
        self.combat_stats.torpedoes
        
    def update_combat_stats(self, stats, hull_integrity):
        """Update combat statistics display"""
        self.combat_stats.torpedoes_fired.set(stats['torpedoes_fired'])
        self.combat_stats.torpedo_hits.set(stats['torpedo_hits'])
        self.combat_stats.ships_sunk.set(stats['ships_sunk'])
        self.combat_stats.submarines_sunk.set(stats['submarines_sunk'])
        self.combat_stats.damage_taken.set(stats['damage_taken'])
        self.combat_stats.hull_integrity.set(hull_integrity)
        
        if hull_integrity > 66:
            self.combat_stats.hull_label.configure(foreground='green')
        elif hull_integrity > 33:
            self.combat_stats.hull_label.configure(foreground='orange')
        else:
            self.combat_stats.hull_label.configure(foreground='red')
            
        if hasattr(self, 'stealth_panel'):
            self.stealth_panel.update_status(
                self.sim.current_noise_level,
                self.sim.detection_status['thermal_layer'],
                self.sim.detection_status
            )

    def draw_compass_rose(self, cx, cy, r):
        """Draw the compass rose with cardinal points"""
        self.compass_canvas.create_oval(cx-r, cy-r, cx+r, cy+r, outline='gray')
        
        points = [
            (0, "N"), (90, "W"), (180, "S"), (270, "E"),
            (45, "NW"), (135, "SW"), (225, "SE"), (315, "NE")
        ]
        
        for angle, label in points:
            x = cx + r * math.cos(math.radians(angle - 90))
            y = cy + r * math.sin(math.radians(angle - 90))
            self.compass_canvas.create_text(x, y, text=label, fill='black', 
                                         font=('Arial', 8, 'bold'))
            
        for i in range(0, 360, 30):
            start_x = cx + (r-10) * math.cos(math.radians(i - 90))
            start_y = cy + (r-10) * math.sin(math.radians(i - 90))
            end_x = cx + r * math.cos(math.radians(i - 90))
            end_y = cy + r * math.sin(math.radians(i - 90))
            self.compass_canvas.create_line(start_x, start_y, end_x, end_y, fill='gray')

    def create_compass_submarine(self, x, y):
        """Create submarine indicator for compass"""
        length = 25
        width = 10
        points = [
            x - length//2, y,
            x - length//4, y - width//2,
            x + length//3, y - width//2,
            x + length//2, y,
            x + length//3, y + width//2,
            x - length//4, y + width//2,
        ]
        return self.compass_canvas.create_polygon(points, fill='gray', outline='black')

class CombatStatsPanel:
    """Panel for displaying combat statistics."""
    def __init__(self, parent):
        self.frame = ttk.LabelFrame(parent, text="Combat Statistics", padding="5")
        
        main_container = ttk.Frame(self.frame)
        main_container.pack(fill="x", padx=5, pady=5)
        
        # Statistics variables
        self.torpedoes_fired = tk.IntVar(value=0)
        self.torpedo_hits = tk.IntVar(value=0)
        self.ships_sunk = tk.IntVar(value=0)
        self.submarines_sunk = tk.IntVar(value=0)
        self.damage_taken = tk.IntVar(value=0)
        self.hull_integrity = tk.IntVar(value=100)
        
        # Hull integrity at top
        hull_container = ttk.Frame(main_container)
        hull_container.pack(fill="x", pady=(0, 10))
        ttk.Label(hull_container, 
                 text="Hull Integrity:", 
                 font=('Arial', 9, 'bold')).pack(side="left")
        self.hull_label = ttk.Label(hull_container, 
                                  textvariable=self.hull_integrity,
                                  font=('Arial', 9, 'bold'))
        self.hull_label.pack(side="left", padx=(5, 0))
        ttk.Label(hull_container, 
                 text="%", 
                 font=('Arial', 9, 'bold')).pack(side="left", padx=(0, 5))
        
        # Combat statistics
        stats_list = [
            ("Torpedoes Fired:", self.torpedoes_fired),
            ("Torpedo Hits:", self.torpedo_hits),
            ("Ships Sunk:", self.ships_sunk),
            ("Submarines Sunk:", self.submarines_sunk),
            ("Damage Taken:", self.damage_taken)
        ]
        
        for text, var in stats_list:
            stat_container = ttk.Frame(main_container)
            stat_container.pack(fill="x", pady=2)
            ttk.Label(stat_container, text=text).pack(side="left")
            ttk.Label(stat_container, textvariable=var).pack(side="left", padx=(5, 0))

class StealthPanel:
    """Panel for displaying stealth-related information."""
    def __init__(self, parent):
        self.frame = ttk.LabelFrame(parent, text="Stealth Status", padding="5")
        
        # Create variables for stealth indicators
        self.noise_level_var = tk.StringVar(value="40 dB")
        self.thermal_layer_var = tk.StringVar(value="Surface")
        self.detection_status_var = tk.StringVar(value="Not Detected")
        self.detected_by_var = tk.StringVar(value="")
        
        # Create container
        main_container = ttk.Frame(self.frame)
        main_container.pack(fill="x", padx=5, pady=5)
        
        # Create status indicators with better styling
        noise_frame = ttk.Frame(main_container)
        noise_frame.pack(fill="x", pady=2)
        ttk.Label(noise_frame, text="Noise Level:").pack(side="left")
        self.noise_label = ttk.Label(noise_frame, textvariable=self.noise_level_var,
                                   font=('Arial', 9))
        self.noise_label.pack(side="left", padx=(5, 0))
        
        layer_frame = ttk.Frame(main_container)
        layer_frame.pack(fill="x", pady=2)
        ttk.Label(layer_frame, text="Thermal Layer:").pack(side="left")
        self.layer_label = ttk.Label(layer_frame, textvariable=self.thermal_layer_var,
                                   font=('Arial', 9))
        self.layer_label.pack(side="left", padx=(5, 0))
        
        status_frame = ttk.Frame(main_container)
        status_frame.pack(fill="x", pady=2)
        ttk.Label(status_frame, text="Detection:").pack(side="left")
        self.status_label = ttk.Label(status_frame, textvariable=self.detection_status_var,
                                    font=('Arial', 9, 'bold'))
        self.status_label.pack(side="left", padx=(5, 0))
        
        detected_frame = ttk.Frame(main_container)
        detected_frame.pack(fill="x", pady=2)
        self.detected_label = ttk.Label(detected_frame, textvariable=self.detected_by_var,
                                      font=('Arial', 8), foreground='red')
        self.detected_label.pack(side="left", padx=(5, 0))
    
    def update_status(self, noise_level, thermal_layer, detection_status):
        """Update stealth status indicators."""
        self.noise_level_var.set(f"{noise_level:.1f} dB")
        self.thermal_layer_var.set(thermal_layer.title())
        
        if detection_status['is_detected']:
            self.detection_status_var.set("DETECTED")
            self.status_label.configure(foreground='red')
            
            if detection_status['detected_by']:
                detected_by = detection_status['detected_by']
                if isinstance(detected_by, Ship):
                    vessel_type = detected_by.ship_type.title()
                elif isinstance(detected_by, Submarine):
                    vessel_type = detected_by.name
                else:
                    vessel_type = "Unknown"
                self.detected_by_var.set(f"Detected by: {vessel_type}")
            else:
                self.detected_by_var.set("")
        else:
            self.detection_status_var.set("Hidden")
            self.status_label.configure(foreground='green')
            self.detected_by_var.set("")
        
        if noise_level < 50:
            self.noise_label.configure(foreground='green')
        elif noise_level < 70:
            self.noise_label.configure(foreground='orange')
        else:
            self.noise_label.configure(foreground='red')
        
        if thermal_layer.lower() == 'surface':
            self.layer_label.configure(foreground='red')
        elif thermal_layer.lower() == 'thermocline':
            self.layer_label.configure(foreground='green')
        else:  # deep
            self.layer_label.configure(foreground='blue')

    def create_visualization(self):
        """Create the side view visualization with thermal layers"""
        self.side_canvas = tk.Canvas(self.view_frame, width=300, height=400, bg='lightblue')
        self.side_canvas.grid(row=0, column=0, padx=10, pady=5, sticky="nsew")
        
        # Draw water surface line
        self.side_canvas.create_line(0, 50, 300, 50, fill='blue', width=2)
        
        # Draw thermal layers
        self.draw_thermal_layers()
        
        # Draw depth markers
        self.draw_depth_markers()
        
        # Create submarine shape
        self.sub_shape = self.create_submarine(150, 200)

    def draw_thermal_layers(self):
        """Draw thermal layer visualization with enhanced detail"""
        # Surface mixed layer (0-50m)
        self.side_canvas.create_rectangle(0, 50, 300, 105, 
                                        fill='#a8d5e5', width=0)
        
        # Transition zone (50-80m)
        self.side_canvas.create_rectangle(0, 105, 300, 138,
                                        fill='#8abfd4', width=0)
        
        # Thermocline (80-200m)
        self.side_canvas.create_rectangle(0, 138, 300, 270, 
                                        fill='#68a4bf', width=0)
        
        # Deep water (>200m)
        self.side_canvas.create_rectangle(0, 270, 300, 400, 
                                        fill='#2c5a7c', width=0)
        
        # Add layer labels
        self.side_canvas.create_text(290, 77, text="Mixed Layer",
                                   anchor="e", fill='black', font=('Arial', 7))
        self.side_canvas.create_text(290, 200, text="Thermocline",
                                   anchor="e", fill='navy', font=('Arial', 7))
        self.side_canvas.create_text(290, 335, text="Deep Water",
                                   anchor="e", fill='white', font=('Arial', 7))

    def draw_depth_markers(self):
        """Draw depth markers"""
        for depth in range(0, 501, 50):
            # Use same scale factor as submarine movement
            y = 50 + (depth * 0.9)
            
            # Draw marker line and depth label
            self.side_canvas.create_line(0, y, 20, y, fill='white', width=1)
            self.side_canvas.create_text(25, y, text=f"{depth}m", 
                                       anchor="w", fill='white', 
                                       font=('Arial', 8))
                
    def _draw_projectile(self, projectile):
        """Draw a gun projectile on the map."""
        size = projectile.size * 1.5
        
        # Create glowing effect
        glow_size = size * 1.5
        self.map_canvas.create_oval(
            projectile.x - glow_size, projectile.y - glow_size,
            projectile.x + glow_size, projectile.y + glow_size,
            fill='#FFE87C',
            outline='',
            tags="weapon"
        )
        
        # Draw main projectile
        self.map_canvas.create_oval(
            projectile.x - size, projectile.y - size,
            projectile.x + size, projectile.y + size,
            fill='orange',
            outline='red',
            width=2,
            tags="weapon"
        )

    def create_submarine(self, x, y):
        """Create submarine shape for side view"""
        points = [
            x - 25, y,
            x - 17, y - 7,
            x + 17, y - 7,
            x + 25, y,
            x + 17, y + 7,
            x - 17, y + 7,
        ]
        return self.side_canvas.create_polygon(points, fill='gray', outline='black', width=2)

    def create_compass_view(self):
        """Create the compass view"""
        compass_frame = ttk.Frame(self.control_frame)
        compass_frame.grid(row=0, column=3, padx=30, pady=5, sticky="ne")
        
        self.compass_canvas = tk.Canvas(compass_frame, width=150, height=150, bg='white')
        self.compass_canvas.pack(padx=5, pady=5)
        
        center_x, center_y = 75, 75
        radius = 60
        
        self.draw_compass_rose(center_x, center_y, radius)
        self.compass_sub = self.create_compass_submarine(center_x, center_y)

    def draw_compass_rose(self, cx, cy, r):
        """Draw the compass rose with cardinal points"""
        self.compass_canvas.create_oval(cx-r, cy-r, cx+r, cy+r, outline='gray')
        
        points = [
            (0, "N"), (90, "W"), (180, "S"), (270, "E"),
            (45, "NW"), (135, "SW"), (225, "SE"), (315, "NE")
        ]
        
        for angle, label in points:
            x = cx + r * math.cos(math.radians(angle - 90))
            y = cy + r * math.sin(math.radians(angle - 90))
            self.compass_canvas.create_text(x, y, text=label, fill='black', 
                                         font=('Arial', 8, 'bold'))
            
        for i in range(0, 360, 30):
            start_x = cx + (r-10) * math.cos(math.radians(i - 90))
            start_y = cy + (r-10) * math.sin(math.radians(i - 90))
            end_x = cx + r * math.cos(math.radians(i - 90))
            end_y = cy + r * math.sin(math.radians(i - 90))
            self.compass_canvas.create_line(start_x, start_y, end_x, end_y, fill='gray')

    def create_compass_submarine(self, x, y):
        """Create submarine indicator for compass"""
        length = 25
        width = 10
        points = [
            x - length//2, y,
            x - length//4, y - width//2,
            x + length//3, y - width//2,
            x + length//2, y,
            x + length//3, y + width//2,
            x - length//4, y + width//2,
        ]
        return self.compass_canvas.create_polygon(points, fill='gray', outline='black')
        
    def create_info_panels(self):
        """Create sonar and information panels."""
        info_frame = ttk.Frame(self.root)
        info_frame.grid(row=1, column=2, padx=15, pady=5, sticky="ne")
        info_frame.grid_columnconfigure(0, minsize=270)

        # Create combat stats panel
        self.combat_stats = CombatStatsPanel(info_frame)
        self.combat_stats.frame.pack(fill="y", pady=(5, 0), expand=False)
            
    def update_compass_view(self):
        """Update compass view with current heading"""
        if self.compass_sub:
            center_x, center_y = 75, 75
            self.compass_canvas.delete(self.compass_sub)
            
            # Create new submarine shape at current heading
            angle = math.radians(self.sim.heading - 90)
            length = 25
            width = 10
            
            # Calculate rotated points
            points = []
            base_points = [
                (-length//2, 0),
                (-length//4, -width//2),
                (length//3, -width//2),
                (length//2, 0),
                (length//3, width//2),
                (-length//4, width//2)
            ]
            
            for x, y in base_points:
                rot_x = x * math.cos(angle) - y * math.sin(angle)
                rot_y = x * math.sin(angle) + y * math.cos(angle)
                points.extend([center_x + rot_x, center_y + rot_y])
            
            self.compass_sub = self.compass_canvas.create_polygon(
                points, fill='gray', outline='black'
            )
        
    def update_depth_warnings(self, depth):
        """Update depth warning indicators"""
        if depth < self.sim.SAFE_DEPTH:
            self.depth_risk_label.configure(
                text="SAFE DEPTH",
                foreground='green'
            )
        elif depth < 330:
            self.depth_risk_label.configure(
                text="RISK OF FAILURE (15%/s)",
                foreground='orange'
            )
        else:
            self.depth_risk_label.configure(
                text="EXTREME RISK (25%/s)",
                foreground='red'
            )
        
class CombatStatsPanel:
    """Panel for displaying combat statistics."""
    def __init__(self, parent):
        self.frame = ttk.LabelFrame(parent, text="Combat Statistics", padding="5")
        
        main_container = ttk.Frame(self.frame)
        main_container.pack(fill="x", padx=5, pady=5)
        
        # Statistics variables
        self.torpedoes_fired = tk.IntVar(value=0)
        self.torpedo_hits = tk.IntVar(value=0)
        self.ships_sunk = tk.IntVar(value=0)
        self.submarines_sunk = tk.IntVar(value=0)
        self.damage_taken = tk.IntVar(value=0)
        self.hull_integrity = tk.IntVar(value=100)
        
        # Hull integrity at top
        hull_container = ttk.Frame(main_container)
        hull_container.pack(fill="x", pady=(0, 10))
        ttk.Label(hull_container, 
                 text="Hull Integrity:", 
                 font=('Arial', 9, 'bold')).pack(side="left")
        self.hull_label = ttk.Label(hull_container, 
                                  textvariable=self.hull_integrity,
                                  font=('Arial', 9, 'bold'))
        self.hull_label.pack(side="left", padx=(5, 0))
        ttk.Label(hull_container, 
                 text="%", 
                 font=('Arial', 9, 'bold')).pack(side="left", padx=(0, 5))
        
        # Combat statistics
        stats_list = [
            ("Torpedoes Fired:", self.torpedoes_fired),
            ("Torpedo Hits:", self.torpedo_hits),
            ("Ships Sunk:", self.ships_sunk),
            ("Submarines Sunk:", self.submarines_sunk),
            ("Damage Taken:", self.damage_taken)
        ]
        
        for text, var in stats_list:
            stat_container = ttk.Frame(main_container)
            stat_container.pack(fill="x", pady=2)
            ttk.Label(stat_container, text=text).pack(side="left")
            ttk.Label(stat_container, textvariable=var).pack(side="left", padx=(5, 0))

    def update_compass_view(self):
        """Update compass view with current heading"""
        if self.compass_sub:
            center_x, center_y = 75, 75
            self.compass_canvas.delete(self.compass_sub)
            
            # Create new submarine shape at current heading
            angle = math.radians(self.sim.heading - 90)
            length = 25
            width = 10
            
            # Calculate rotated points
            points = []
            base_points = [
                (-length//2, 0),
                (-length//4, -width//2),
                (length//3, -width//2),
                (length//2, 0),
                (length//3, width//2),
                (-length//4, width//2)
            ]
            
            for x, y in base_points:
                rot_x = x * math.cos(angle) - y * math.sin(angle)
                rot_y = x * math.sin(angle) + y * math.cos(angle)
                points.extend([center_x + rot_x, center_y + rot_y])
            
            self.compass_sub = self.compass_canvas.create_polygon(
                points, fill='gray', outline='black'
            )

    def animate_explosion(self, x, y):
        """Create explosion animation at specified coordinates"""
        # Keep explosions in bounds
        x = max(40, min(2360, x))
        y = max(40, min(1560, y))
        
        colors = ['yellow', 'orange', 'red', 'gray']
        sizes = [10, 20, 30, 40, 30, 20, 10]
        explosions = []
        
        def animate_frame(frame):
            # Clear previous frame
            for exp in explosions:
                self.map_canvas.delete(exp)
            explosions.clear()
            
            if frame < len(sizes):
                size = sizes[frame]
                color = colors[min(frame, len(colors)-1)]
                
                # Create explosion circle
                exp = self.map_canvas.create_oval(
                    x - size, y - size,
                    x + size, y + size,
                    fill=color, outline=color
                )
                explosions.append(exp)
                
                # Schedule next frame
                self.root.after(100, lambda: animate_frame(frame + 1))
            else:
                # Clean up explosions list when animation is complete
                self.active_explosions = [e for e in self.active_explosions if e not in explosions]
        
        # Start animation
        animate_frame(0)
        
        # Track this explosion
        self.active_explosions.extend(explosions)

    def get_thermal_layer(self, depth):
        """Get thermal layer description based on depth."""
        if depth <= 50:
            return "SURFACE"
        elif 80 <= depth <= 200:
            return "THERMOCLINE"
        else:
            return "DEEP"

    def update_depth_warnings(self, depth):
        """Update depth warning indicators"""
        if depth < self.sim.SAFE_DEPTH:
            self.depth_risk_label.configure(
                text="SAFE DEPTH",
                foreground='green'
            )
        elif depth < 330:
            self.depth_risk_label.configure(
                text="RISK OF FAILURE (15%/s)",
                foreground='orange'
            )
        else:
            self.depth_risk_label.configure(
                text="EXTREME RISK (25%/s)",
                foreground='red'
            )

    def update_torpedo_button_state(self, time_since_last, reload_time):
        """Update torpedo button state with debugging."""
        if time_since_last < reload_time:
            self.torpedo_button.configure(state='disabled')
            remaining = reload_time - time_since_last
            self.torpedo_button.configure(text=f"Reloading... ({remaining:.1f}s)")
            print(f"Torpedo reloading: {remaining:.1f}s remaining")
        else:
            self.torpedo_button.configure(state='normal')
            self.torpedo_button.configure(text="Launch Torpedo!")
            print("Torpedo ready to fire")

    def create_info_panels(self):
        """Create sonar and information panels."""
        info_frame = ttk.Frame(self.root)
        info_frame.grid(row=1, column=2, padx=15, pady=5, sticky="ne")
        info_frame.grid_columnconfigure(0, minsize=270)
    
        # Create stealth panel
        self.stealth_panel = StealthPanel(info_frame)
        self.stealth_panel.frame.pack(fill="y", pady=(0, 5), expand=False)
    
        # Create combat stats panel
        self.combat_stats = CombatStatsPanel(info_frame)
        self.combat_stats.frame.pack(fill="y", pady=(5, 0), expand=False)

    def update_combat_stats(self, stats, hull_integrity):
        """Update combat statistics display"""
        self.combat_stats.torpedoes_fired.set(stats['torpedoes_fired'])
        self.combat_stats.torpedo_hits.set(stats['torpedo_hits'])
        self.combat_stats.ships_sunk.set(stats['ships_sunk'])
        self.combat_stats.submarines_sunk.set(stats['submarines_sunk'])
        self.combat_stats.damage_taken.set(stats['damage_taken'])
        self.combat_stats.hull_integrity.set(hull_integrity)
        
        if hull_integrity > 66:
            self.combat_stats.hull_label.configure(foreground='green')
        elif hull_integrity > 33:
            self.combat_stats.hull_label.configure(foreground='orange')
        else:
            self.combat_stats.hull_label.configure(foreground='red')

class SonarContactDisplay:
        """Panel for displaying and managing sonar contacts."""
        def __init__(self, parent):
            self.frame = ttk.LabelFrame(parent, text="Sonar Contacts", padding="5")
            
            # Main container
            self.main_container = ttk.Frame(self.frame)
            self.main_container.pack(fill="both", expand=True, padx=5, pady=5)
            
            # Create Treeview for contacts
            self.contacts_tree = ttk.Treeview(
                self.main_container,
                columns=("type", "range", "bearing", "depth", "solution"),
                show="headings",
                height=8
            )
            
            # Configure columns
            columns = {
                "type": ("Type", 80),
                "range": ("Range", 60),
                "bearing": ("Brg", 50),
                "depth": ("Depth", 60),
                "solution": ("Sol", 50)
            }
            
            for col, (heading, width) in columns.items():
                self.contacts_tree.heading(col, text=heading)
                self.contacts_tree.column(col, width=width)
            
            # Configure tags for solution quality
            self.contacts_tree.tag_configure('FIRM', foreground='green')
            self.contacts_tree.tag_configure('WEAK', foreground='orange')
            self.contacts_tree.tag_configure('UNCERTAIN', foreground='red')
            
            # Add scrollbar
            scrollbar = ttk.Scrollbar(
                self.main_container,
                orient="vertical",
                command=self.contacts_tree.yview
            )
            self.contacts_tree.configure(yscrollcommand=scrollbar.set)
            
            # Pack elements
            self.contacts_tree.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")
            
        def update_contacts(self, contacts):
            """Update the contacts display."""
            # Clear existing items
            for item in self.contacts_tree.get_children():
                self.contacts_tree.delete(item)
            
            # Add new contacts
            for contact in contacts:
                values = (
                    contact.get('type', 'Unknown'),
                    f"{float(contact.get('range', 0)):.1f}km",
                    f"{float(contact.get('bearing', 0)):.0f}°",
                    f"{float(contact.get('depth', 0)):.0f}m",
                    contact.get('solution', 'UNCERTAIN')
                )
                
                # Insert with appropriate tag for solution quality
                self.contacts_tree.insert(
                    "",
                    "end",
                    values=values,
                    tags=(contact.get('solution', 'UNCERTAIN'),)
                )

class CombatStatsPanel:
    """Panel for displaying combat statistics."""
    def __init__(self, parent):
        self.frame = ttk.LabelFrame(parent, text="Combat Statistics", padding="5")
        
        main_container = ttk.Frame(self.frame)
        main_container.pack(fill="x", padx=5, pady=5)
        
        # Statistics variables
        self.torpedoes_fired = tk.IntVar(value=0)
        self.torpedo_hits = tk.IntVar(value=0)
        self.ships_sunk = tk.IntVar(value=0)
        self.submarines_sunk = tk.IntVar(value=0)
        self.damage_taken = tk.IntVar(value=0)
        self.hull_integrity = tk.IntVar(value=100)
        
        # Hull integrity at top
        hull_container = ttk.Frame(main_container)
        hull_container.pack(fill="x", pady=(0, 10))
        ttk.Label(hull_container, 
                 text="Hull Integrity:", 
                 font=('Arial', 9, 'bold')).pack(side="left")
        self.hull_label = ttk.Label(hull_container, 
                                  textvariable=self.hull_integrity,
                                  font=('Arial', 9, 'bold'))
        self.hull_label.pack(side="left", padx=(5, 0))
        ttk.Label(hull_container, 
                 text="%", 
                 font=('Arial', 9, 'bold')).pack(side="left", padx=(0, 5))
        
        # Combat statistics
        stats_list = [
            ("Torpedoes Fired:", self.torpedoes_fired),
            ("Torpedo Hits:", self.torpedo_hits),
            ("Ships Sunk:", self.ships_sunk),
            ("Submarines Sunk:", self.submarines_sunk),
            ("Damage Taken:", self.damage_taken)
        ]
        
        for text, var in stats_list:
            stat_container = ttk.Frame(main_container)
            stat_container.pack(fill="x", pady=2)
            ttk.Label(stat_container, text=text).pack(side="left")
            ttk.Label(stat_container, textvariable=var).pack(side="left", padx=(5, 0))

class StealthPanel:
    """Panel for displaying stealth-related information."""
    def __init__(self, parent):
        self.frame = ttk.LabelFrame(parent, text="Stealth Status", padding="5")
        
        # Create variables for stealth indicators
        self.noise_level_var = tk.StringVar(value="40 dB")
        self.thermal_layer_var = tk.StringVar(value="Surface")
        self.detection_status_var = tk.StringVar(value="Not Detected")
        self.detected_by_var = tk.StringVar(value="")
        
        # Create container
        main_container = ttk.Frame(self.frame)
        main_container.pack(fill="x", padx=5, pady=5)
        
        # Create status indicators with better styling
        noise_frame = ttk.Frame(main_container)
        noise_frame.pack(fill="x", pady=2)
        ttk.Label(noise_frame, text="Noise Level:").pack(side="left")
        self.noise_label = ttk.Label(noise_frame, textvariable=self.noise_level_var,
                                   font=('Arial', 9))
        self.noise_label.pack(side="left", padx=(5, 0))
        
        layer_frame = ttk.Frame(main_container)
        layer_frame.pack(fill="x", pady=2)
        ttk.Label(layer_frame, text="Thermal Layer:").pack(side="left")
        self.layer_label = ttk.Label(layer_frame, textvariable=self.thermal_layer_var,
                                   font=('Arial', 9))
        self.layer_label.pack(side="left", padx=(5, 0))
        
        status_frame = ttk.Frame(main_container)
        status_frame.pack(fill="x", pady=2)
        ttk.Label(status_frame, text="Detection:").pack(side="left")
        self.status_label = ttk.Label(status_frame, textvariable=self.detection_status_var,
                                    font=('Arial', 9, 'bold'))
        self.status_label.pack(side="left", padx=(5, 0))
        
        detected_frame = ttk.Frame(main_container)
        detected_frame.pack(fill="x", pady=2)
        self.detected_label = ttk.Label(detected_frame, textvariable=self.detected_by_var,
                                      font=('Arial', 8), foreground='red')
        self.detected_label.pack(side="left", padx=(5, 0))
    
    def update_status(self, noise_level, thermal_layer, detection_status):
        """Update stealth status indicators."""
        self.noise_level_var.set(f"{noise_level:.1f} dB")
        self.thermal_layer_var.set(thermal_layer.title())
        
        if detection_status['is_detected']:
            self.detection_status_var.set("DETECTED")
            self.status_label.configure(foreground='red')
            
            if detection_status['detected_by']:
                detected_by = detection_status['detected_by']
                if isinstance(detected_by, Ship):
                    vessel_type = detected_by.ship_type.title()
                elif isinstance(detected_by, Submarine):
                    vessel_type = detected_by.name
                else:
                    vessel_type = "Unknown"
                self.detected_by_var.set(f"Detected by: {vessel_type}")
            else:
                self.detected_by_var.set("")
        else:
            self.detection_status_var.set("Hidden")
            self.status_label.configure(foreground='green')
            self.detected_by_var.set("")
        
        if noise_level < 50:
            self.noise_label.configure(foreground='green')
        elif noise_level < 70:
            self.noise_label.configure(foreground='orange')
        else:
            self.noise_label.configure(foreground='red')
        
        if thermal_layer.lower() == 'surface':
            self.layer_label.configure(foreground='red')
        elif thermal_layer.lower() == 'thermocline':
            self.layer_label.configure(foreground='green')
        else:  # deep
            self.layer_label.configure(foreground='blue')
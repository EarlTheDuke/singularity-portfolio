"""
Classes representing ships, submarines, and weapons in the simulation.
Enhanced with submarine capabilities and weapon systems.
"""

from collections import deque
import math
import random
import time

class SubmarinePhysics:
    """Physics model for submarine noise, detection, and thermal layer effects."""
    
    def __init__(self):
        """Initialize physics model with balanced detection capabilities."""
        # Basic submarine characteristics
        self.hull_length = 110  # meters (default Los Angeles class)
        self.displacement = 6900  # tons
        self.max_depth = 290  # meters
        self.test_depth = 250  # meters
        
        # Balanced detection ranges
        self.surface_detection_range = 4000  # Balanced from extreme values
        self.base_sonar_range = 4000
        self.torpedo_firing_detection_time = 15
        self.last_torpedo_time = 0
        
        # Balanced low-speed sonar performance
        self.optimal_sonar_speed = 8.0  # Back to reasonable value
        self.sonar_degradation_start = 12.0
        self.severe_degradation_speed = 18.0
        
        # Balanced noise characteristics
        self.cavitation_speed = 25  # Standard cavitation speed
        self.minimum_noise_level = 30
        self.machinery_noise_base = 45
        self.torpedo_noise = 90
        
        # Thermal layer configuration
        self.surface_layer_depth = 50
        self.thermocline_layer_start = 80
        self.thermocline_layer_end = 200
        self.deep_layer_reduction = 0.5
        
        # Balanced submarine modifiers (LA class slightly better than Yasen)
        self.sub_type_modifiers = {
            'los_angeles': {
                'noise_multiplier': 0.8,
                'detection_multiplier': 2.2   # Slightly better than Yasen
            },
            'yasen': {
                'noise_multiplier': 0.7,
                'detection_multiplier': 2.0
            }
        }
        
        # Layer acoustic properties with balanced values
        self.layer_properties = {
            'surface': {
                'noise_multiplier': 1.0,
                'detection_multiplier': 1.2,
                'cross_layer_loss': 0.8
            },
            'thermocline': {
                'noise_multiplier': 0.8,
                'detection_multiplier': 1.3,
                'cross_layer_loss': 0.7
            },
            'deep': {
                'noise_multiplier': 0.6,
                'detection_multiplier': 1.1,
                'cross_layer_loss': 0.8
            }
        }
        
    def calculate_sonar_efficiency(self, speed):
        """Calculate sonar efficiency based on speed with dramatically enhanced low-speed performance."""
        if speed <= self.optimal_sonar_speed:
            return 2.0  # 100% bonus at optimal speeds (increased from 1.5)
        elif speed <= self.sonar_degradation_start:
            # Linear degradation from optimal to degradation start
            factor = (self.sonar_degradation_start - speed) / (self.sonar_degradation_start - self.optimal_sonar_speed)
            return 1.5 + (0.5 * factor)  # Scales from 2.0 to 1.5
        elif speed <= self.severe_degradation_speed:
            # Linear degradation from 1.5 to 0.8
            factor = (self.severe_degradation_speed - speed) / (self.severe_degradation_speed - self.sonar_degradation_start)
            return 0.8 + (0.7 * factor)
        else:
            return 0.8  # Minimum efficiency increased at high speeds
    
    def calculate_noise_level(self, speed, depth, sub_type='los_angeles'):
        """Calculate submarine's current noise level in dB."""
        # Base machinery noise
        noise = self.machinery_noise_base
        
        # Speed-based noise
        if speed > self.cavitation_speed:
            noise += (speed - self.cavitation_speed) * 3
        else:
            noise += speed * 1.5
            
        # Apply submarine type modifier
        if sub_type in self.sub_type_modifiers:
            noise *= self.sub_type_modifiers[sub_type]['noise_multiplier']
            
        # Apply thermal layer effects
        layer = self.get_thermal_layer(depth)
        noise *= self.layer_properties[layer]['noise_multiplier']
            
        return max(self.minimum_noise_level, noise)
    
    def get_thermal_layer(self, depth):
        """Determine which thermal layer a depth is in."""
        if depth <= self.surface_layer_depth:
            return 'surface'
        elif self.thermocline_layer_start <= depth <= self.thermocline_layer_end:
            return 'thermocline'
        else:
            return 'deep'
    
    def calculate_detection_range(self, noise_level, depth, sub_type='los_angeles'):
        """Calculate detection range with reduced capabilities."""
        if depth <= 0:  # Surface detection
            return self.surface_detection_range  # Keep surface detection the same
            
        # Reduced base range calculation - divided by 4
        base_range = (noise_level - self.minimum_noise_level) * 2  # Reduced from 8
        
        # Apply submarine type modifier with reduced multipliers
        if sub_type in self.sub_type_modifiers:
            base_range *= self.sub_type_modifiers[sub_type]['detection_multiplier'] * 0.625  # Reduced from 2.5
        
        # Apply thermal layer effects with reduced multipliers
        layer = self.get_thermal_layer(depth)
        layer_multiplier = {
            'surface': 0.8,
            'thermocline': 1.25,  # Reduced from 1.5
            'deep': 1.0  # Reduced from 1.2
        }.get(layer, 1.0)
        base_range *= layer_multiplier
        
        return max(200, min(base_range, self.surface_detection_range))

    def calculate_cross_layer_detection(self, source_depth, target_depth, base_detection_range):
        """Calculate detection range modification for crossing thermal layers with reduced capabilities."""
        source_layer = self.get_thermal_layer(source_depth)
        target_layer = self.get_thermal_layer(target_depth)
        
        if source_layer == target_layer:
            return base_detection_range * 0.25  # Apply 1/4 reduction to same-layer detection
        
        # Calculate total signal loss with increased penalties
        total_loss = 0.25  # Start with base 1/4 reduction
        if source_layer != target_layer:
            total_loss *= self.layer_properties[source_layer]['cross_layer_loss']
            total_loss *= self.layer_properties[target_layer]['cross_layer_loss']
            
        return base_detection_range * total_loss
    
    def calculate_cross_layer_detection(self, source_depth, target_depth, base_detection_range):
        """Calculate detection range modification for crossing thermal layers."""
        source_layer = self.get_thermal_layer(source_depth)
        target_layer = self.get_thermal_layer(target_depth)
        
        if source_layer == target_layer:
            return base_detection_range
        
        # Calculate total signal loss
        total_loss = 1.0
        if source_layer != target_layer:
            total_loss *= self.layer_properties[source_layer]['cross_layer_loss']
            total_loss *= self.layer_properties[target_layer]['cross_layer_loss']
            
        return base_detection_range * total_loss
    
    def is_detectable(self, current_time, observer_pos, sub_pos, speed, depth, 
                     sub_type='los_angeles', observer_depth=0):
        """Determine if submarine is detectable by an observer."""
        # Always detectable if surfaced or recently fired
        if depth <= 0 or (current_time - self.last_torpedo_time < self.torpedo_firing_detection_time):
            return True, self.surface_detection_range
            
        # Calculate base detection range
        noise = self.calculate_noise_level(speed, depth, sub_type)
        base_range = self.calculate_detection_range(noise, depth, sub_type)
        
        # Modify for cross-layer detection
        actual_range = self.calculate_cross_layer_detection(observer_depth, depth, base_range)
        
        # Calculate actual distance
        distance = math.hypot(observer_pos[0] - sub_pos[0], 
                            observer_pos[1] - sub_pos[1])
                   
        return distance <= actual_range, actual_range
    
    def update_torpedo_firing(self, current_time):
        """Update torpedo firing time for detection purposes."""
        self.last_torpedo_time = current_time

class Ship:
    """Base class for all surface vessels."""
    def __init__(self, x, y, heading, ship_type="merchant"):
        """Initialize a ship."""
        self.x = x
        self.y = y
        self.heading = heading
        self.speed = 0.0
        self.ship_type = ship_type
        self.size = 15
        self.track_history = deque(maxlen=100)
        self.is_active = True
        self.target_heading = heading
        self.turn_rate = 2.0  # degrees per second
        
        # Set health and characteristics based on ship type
        if ship_type == "merchant":
            self.health = 50
            self.max_speed = 15.0
            self.color = 'blue'
            self.length = 15
            self.width = 5
            self.has_weapons = False
        else:  # warship
            self.health = 100
            self.max_speed = 25.0
            self.color = 'gray'
            self.length = 12
            self.width = 4
            self.has_weapons = True
            self.gun_range = 250  # Surface gun range
            self.torpedo_range = 175  # 7 grid squares
            self.gun_reload_time = 3.0  # Seconds between gun shots
            self.torpedo_reload_time = 15.0  # Seconds between torpedo shots
            self.last_gun_shot = 0
            self.last_torpedo_shot = 0
            self.detection_range = 300  # General detection range
    
    def can_fire_guns(self, current_time):
        """Check if ship can fire guns based on reload time."""
        if not self.has_weapons:
            return False
        return (current_time - self.last_gun_shot) >= self.gun_reload_time

    def can_fire_torpedo(self, current_time):
        """Check if ship can fire torpedo based on reload time."""
        if not self.has_weapons:
            return False
        return (current_time - self.last_torpedo_shot) >= self.torpedo_reload_time

    def get_distance_to_target(self, target_x, target_y):
        """Calculate distance to target."""
        return math.hypot(self.x - target_x, self.y - target_y)

    def calculate_target_bearing(self, target_x, target_y):
        """Calculate bearing to target in degrees."""
        dx = target_x - self.x
        dy = target_y - self.y
        bearing = math.degrees(math.atan2(dx, -dy)) % 360
        return bearing

    def calculate_lead_position(self, target_x, target_y, target_heading, target_speed, lead_time):
        """Calculate lead position for targeting moving vessels."""
        heading_rad = math.radians(target_heading)
        target_vx = target_speed * math.sin(heading_rad)
        target_vy = -target_speed * math.cos(heading_rad)
        future_x = target_x + (target_vx * lead_time)
        future_y = target_y + (target_vy * lead_time)
        return future_x, future_y

class Submarine(Ship):
    """Enhanced submarine class with advanced warfare capabilities."""
    
    # Class-level submarine type specifications
    SUBMARINE_TYPES = {
        "los_angeles": {
            "name": "Los Angeles Class",
            "max_depth": 290,
            "test_depth": 250,
            "max_speed": 25.0,
            "length": 110.0,
            "displacement": 6900,
            "base_noise": 60,
            "cavitation_speed": 20,
            "torpedo_tubes": 4,
            "has_vls": False,
            "nation": "USA",
            "sonar_range_multiplier": 1.0
        },
        "yasen": {
            "name": "Yasen Class",
            "max_depth": 600,
            "test_depth": 520,
            "max_speed": 35.0,
            "length": 139.0,
            "displacement": 13800,
            "base_noise": 55,  # Lower than Los Angeles due to advanced propulsion
            "cavitation_speed": 25,
            "torpedo_tubes": 8,
            "has_vls": True,
            "nation": "Russia",
            "sonar_range_multiplier": 1.2  # 20% better sonar
        }
    }
    
    def __init__(self, x, y, heading, sub_type="los_angeles", is_friendly=True):
        """Initialize a submarine with specific type characteristics."""
        super().__init__(x, y, heading, ship_type="submarine")
        
        # Get submarine type specifications
        self.sub_type = sub_type
        self.specs = self.SUBMARINE_TYPES[sub_type]
        self.is_friendly = is_friendly
        
        # Basic characteristics
        self.name = self.specs["name"]
        self.length = self.specs["length"] / 2  # Scaled for display
        self.width = 4
        self.max_speed = self.specs["max_speed"]
        self.max_depth = self.specs["max_depth"]
        self.test_depth = self.specs["test_depth"]
        self.displacement = self.specs["displacement"]
        
        # Depth handling
        self.depth = 0.0
        self.target_depth = 0.0
        self.vertical_velocity = 0.0
        self.max_depth_rate = 5.0  # meters per second
        
        # Combat characteristics
        self.health = 100
        self.has_weapons = True
        self.torpedo_tubes = self.specs["torpedo_tubes"]
        self.has_vls = self.specs["has_vls"]
        self.torpedo_range = 200
        self.torpedo_reload_time = 20.0  # seconds
        self.tubes_loaded = self.torpedo_tubes
        self.last_tube_reload = 0
        self.last_torpedo_shot = 0
        
        # Initialize physics and detection systems
        self.physics = SubmarinePhysics()
        self.physics.machinery_noise_base = self.specs["base_noise"]
        self.physics.cavitation_speed = self.specs["cavitation_speed"]
        
        # Stealth and detection
        self.current_noise_level = self.physics.minimum_noise_level
        self.detection_range = self.physics.surface_detection_range
        self.is_detected = False
        self.last_known_contact = None
        
        # Enhanced detection capabilities
        self.sonar_range_multiplier = self.specs["sonar_range_multiplier"]

        # AI behavior state
        self.ai_state = "patrol" if not is_friendly else None
        self.patrol_depth = random.uniform(100, 300)
        self.evasion_depth = None
        self.last_ai_update = time.time()
        self.search_start_time = 0
        self.search_center = (self.x, self.y)
        self.last_known_contact = None
        self.target_heading = heading
        self.target_speed = 0
        self.target_depth = 0
        self.turn_rate = 2.0  # degrees per second
        
    def calculate_passive_sonar_detection(self, target_sub, range_multiplier=16.0):  # Reduced from 64.0
        """Enhanced passive sonar detection with reduced capabilities."""
        # Calculate basic range and bearing
        dx = target_sub.x - self.x
        dy = target_sub.y - self.y
        distance = math.hypot(dx, dy)
        bearing = math.degrees(math.atan2(dx, -dy)) % 360
        
        # Get thermal layers
        observer_layer = self.get_thermal_layer()
        target_layer = target_sub.get_thermal_layer()
        
        # Calculate base detection range with reduced multiplier
        base_detection_range = self.physics.calculate_detection_range(
            target_sub.current_noise_level * 1.25,  # Reduced from 1.5
            target_sub.depth,
            target_sub.sub_type
        ) * range_multiplier
        
        # Apply speed-based sonar efficiency with reduced bonus
        sonar_efficiency = self.physics.calculate_sonar_efficiency(self.speed) * 1.25  # Reduced from 1.5
        base_detection_range *= sonar_efficiency
        
        # Apply thermal layer effects with increased penalties
        if observer_layer != target_layer:
            base_detection_range *= 0.7  # Increased penalty from 0.9
        
        # Reduced detection strength calculation
        detection_strength = 0.0
        if distance <= base_detection_range:
            detection_strength = 1.0 - (distance / base_detection_range)
            detection_strength = min(1.0, detection_strength * 1.25)  # Reduced from 1.5
            detection_strength *= self.sonar_range_multiplier
            
            # Reduced detection bonus for cavitating targets
            if target_sub.speed > target_sub.physics.cavitation_speed:
                detection_strength *= 1.5  # Reduced from 2.0
                
            # Increased penalty for own speed
            if self.speed > 15:
                detection_strength *= 0.85  # Increased penalty from 0.95
        
        # Reduced bearing quality calculation
        bearing_quality = detection_strength * 0.8  # Added reduction factor
        if self.speed <= self.physics.optimal_sonar_speed:
            bearing_quality *= 1.2  # Reduced from 1.4
        elif self.speed > 10:
            bearing_quality *= 0.9  # Increased penalty from 0.99
            
        if target_sub.speed < 5:
            bearing_quality *= 0.9  # Increased penalty from 0.95
            
        is_detected = detection_strength > 0.15  # Increased detection threshold from 0.1
        
        return is_detected, detection_strength, bearing_quality

    def get_thermal_layer(self):
        """Get submarine's current thermal layer."""
        if self.depth <= self.physics.surface_layer_depth:
            return 'surface'
        elif (self.depth >= self.physics.thermocline_layer_start and 
              self.depth <= self.physics.thermocline_layer_end):
            return 'thermocline'
        return 'deep'

    def calculate_contact_confidence(self, strength, bearing_quality):
        """Calculate overall confidence in contact classification."""
        # Combine various factors for contact confidence
        confidence = (strength * 0.6) + (bearing_quality * 0.4)
        
        # Adjust for submarine type advantages
        if self.sub_type == "yasen":
            confidence *= 1.1  # 10% better confidence for advanced sonar
        
        # Add some noise/uncertainty
        confidence *= random.uniform(0.9, 1.0)
        
        # Cap at maximum of 1.0
        return min(1.0, confidence)
    
    def get_solution_quality(self, confidence):
        """Determine solution quality based on confidence value."""
        if confidence >= 0.8:
            return "FIRM"
        elif confidence >= 0.5:
            return "WEAK"
        return "UNCERTAIN"
    
    def update_contact_position(self, contact):
        """Update contact position with uncertainty factors."""
        # Basic position
        contact['x'] = self.x
        contact['y'] = self.y
        
        # Add range and bearing
        dx = self.x - contact['observer_x']
        dy = self.y - contact['observer_y']
        contact['range'] = math.hypot(dx, dy) / 25  # Convert to km
        contact['bearing'] = math.degrees(math.atan2(dx, -dy)) % 360
        
        # Update solution quality
        strength = contact.get('strength', 0.5)
        bearing_quality = contact.get('bearing_quality', 0.5)
        confidence = self.calculate_contact_confidence(strength, bearing_quality)
        contact['solution'] = self.get_solution_quality(confidence)
        
        return contact
    
    def update_noise_level(self, current_time):
        """Update submarine's noise level with type-specific characteristics."""
        self.current_noise_level = self.physics.calculate_noise_level(
            self.speed, self.depth, self.sub_type
        )
        
        # Apply submarine type-specific modifiers
        if self.sub_type == "yasen":
            # Yasen is quieter at higher speeds
            if self.speed < self.specs["cavitation_speed"]:
                self.current_noise_level *= 0.85
        
        self.detection_range = self.physics.calculate_detection_range(
            self.current_noise_level, self.depth, self.sub_type
        )
        
        if self.last_torpedo_shot:
            self.physics.update_torpedo_firing(current_time)

    def detect_target(self, target_sub):
        """Enhanced submarine-vs-submarine detection with reduced ranges."""
        if not isinstance(target_sub, Submarine):
            return False, 0
            
        # Calculate base detection parameters
        dx = target_sub.x - self.x
        dy = target_sub.y - self.y
        distance = math.hypot(dx, dy)
        
        # Get detection status considering thermal layers with reduced range
        is_detected, range = self.physics.is_detectable(
            time.time(),
            (self.x, self.y),
            (target_sub.x, target_sub.y),
            target_sub.speed,
            target_sub.depth,
            target_sub.sub_type,
            self.depth
        )
        
        # Apply reduced submarine-specific sonar capabilities
        range *= (self.sonar_range_multiplier * 0.25)  # Apply 1/4 reduction
            
        return distance < range, range

    def fire_torpedo(self, target_bearing):
        """Fire a torpedo if tubes are loaded."""
        current_time = time.time()
        if self.tubes_loaded > 0 and (current_time - self.last_torpedo_shot >= self.torpedo_reload_time):
            self.tubes_loaded -= 1
            self.last_torpedo_shot = current_time
            
            # Calculate spawn position
            spawn_distance = 20
            heading_rad = math.radians(target_bearing)
            spawn_x = self.x + spawn_distance * math.sin(heading_rad)
            spawn_y = self.y - spawn_distance * math.cos(heading_rad)
            
            # Create torpedo with enhanced underwater capabilities
            return Torpedo(spawn_x, spawn_y, target_bearing, friendly=self.is_friendly,
                         launch_depth=self.depth)
        return None
    
    def reload_torpedo_tube(self, current_time):
        """Reload a torpedo tube."""
        if (self.tubes_loaded < self.torpedo_tubes and 
            current_time - self.last_tube_reload >= self.torpedo_reload_time):
            self.tubes_loaded += 1
            self.last_tube_reload = current_time
            
    def get_thermal_layer(self):
        """Get submarine's current thermal layer."""
        if self.depth <= self.physics.surface_layer_depth:
            return 'surface'
        elif (self.depth >= self.physics.thermocline_layer_start and 
              self.depth <= self.physics.thermocline_layer_end):
            return 'thermocline'
        return 'deep'

    def update_ai_behavior(self, current_time, player_sub):
        """Update AI behavior for enemy submarines."""
        if self.is_friendly:
            return
            
        dt = current_time - self.last_ai_update
        self.last_ai_update = current_time
        
        # Get detection status of player
        player_detected, detection_range = self.detect_target(player_sub)
        
        # Update AI state based on situation
        if self.ai_state == "patrol":
            if player_detected:
                self.ai_state = "hunting"
                self.last_known_contact = (player_sub.x, player_sub.y, player_sub.depth)
                print(f"Enemy sub transitioning to hunting mode at {self.x}, {self.y}")
        
        elif self.ai_state == "hunting":
            if not player_detected:
                self.ai_state = "last_known_position"
                print(f"Enemy sub lost contact, moving to last known position")
            else:
                self.last_known_contact = (player_sub.x, player_sub.y, player_sub.depth)
        
        elif self.ai_state == "last_known_position":
            if player_detected:
                self.ai_state = "hunting"
            elif self._reached_last_known_position():
                self.ai_state = "search_pattern"
                self.search_start_time = current_time
                self.search_center = (self.x, self.y)
                print(f"Enemy sub starting search pattern")
        
        elif self.ai_state == "search_pattern":
            if player_detected:
                self.ai_state = "hunting"
            elif current_time - self.search_start_time > 120:  # 2 minutes max search
                self.ai_state = "patrol"
                print(f"Enemy sub returning to patrol")
        
        elif self.ai_state == "evading":
            if not player_detected and current_time - self.evasion_start > 60:
                self.ai_state = "patrol"
                print(f"Enemy sub ending evasion")
        
        # Execute behavior based on state
        self._execute_ai_behavior(dt, player_sub)

    def _execute_ai_behavior(self, dt, player_sub):
        """Execute specific AI behaviors based on current state."""
        if self.ai_state == "patrol":
            # Regular patrol behavior with improved randomization
            self.target_depth = self.patrol_depth
            
            # Occasionally change patrol parameters
            if random.random() < 0.02:  # 2% chance per update
                # Choose new heading based on current position
                if self.x < 200:  # Near left edge
                    self.target_heading = random.uniform(-45, 45)
                elif self.x > 1000:  # Near right edge
                    self.target_heading = random.uniform(135, 225)
                elif self.y < 200:  # Near top edge
                    self.target_heading = random.uniform(45, 135)
                elif self.y > 600:  # Near bottom edge
                    self.target_heading = random.uniform(225, 315)
                else:
                    self.target_heading = random.uniform(0, 360)
                
                # Vary patrol depth
                self.patrol_depth = random.uniform(100, 300)
            
            # Maintain patrol speed
            self.target_speed = random.uniform(5, 12)
            
        elif self.ai_state == "hunting":
            # Enhanced hunting behavior with intercept calculations
            dx = player_sub.x - self.x
            dy = player_sub.y - self.y
            distance = math.hypot(dx, dy)
            
            # Calculate intercept course
            lead_time = distance / (self.max_speed * 0.5)  # Simplified intercept
            future_x = player_sub.x + (player_sub.speed * math.sin(math.radians(player_sub.heading)) * lead_time)
            future_y = player_sub.y - (player_sub.speed * math.cos(math.radians(player_sub.heading)) * lead_time)
            
            # Calculate heading to intercept point
            intercept_heading = math.degrees(math.atan2(future_x - self.x, -(future_y - self.y))) % 360
            self.target_heading = intercept_heading
            
            # Adjust depth based on target and thermal layers
            if abs(player_sub.depth - self.depth) > 50:
                self.target_depth = player_sub.depth
            
            # Set speed based on distance
            if distance < 200:
                self.target_speed = max(5, player_sub.speed - 2)  # Slow down for better tracking
            else:
                self.target_speed = min(20, self.max_speed * 0.8)
            
            # Fire torpedo if conditions are met
            if self._should_fire_torpedo(player_sub):
                self.fire_torpedo(self.target_heading)
            
        elif self.ai_state == "last_known_position":
            # Move to last known contact position
            if self.last_known_contact:
                dx = self.last_known_contact[0] - self.x
                dy = self.last_known_contact[1] - self.y
                self.target_heading = math.degrees(math.atan2(dx, -dy)) % 360
                self.target_depth = self.last_known_contact[2]
                self.target_speed = 15
            
        elif self.ai_state == "search_pattern":
            # Execute expanding spiral search pattern
            time_in_search = time.time() - self.search_start_time
            spiral_radius = 50 + (time_in_search * 2)  # Expanding radius
            angle = time_in_search * 0.5  # Rotation rate
            
            # Calculate position in spiral
            target_x = self.search_center[0] + spiral_radius * math.cos(angle)
            target_y = self.search_center[1] + spiral_radius * math.sin(angle)
            
            # Calculate heading to maintain spiral
            dx = target_x - self.x
            dy = target_y - self.y
            self.target_heading = math.degrees(math.atan2(dx, -dy)) % 360
            
            # Maintain search speed and depth
            self.target_speed = 10
            self.target_depth = 150  # Mid-depth for better sonar coverage
            
        elif self.ai_state == "evading":
            if not self.evasion_depth:
                # Choose evasion depth in different thermal layer
                if self.depth < 200:
                    self.evasion_depth = random.uniform(250, self.test_depth)
                else:
                    self.evasion_depth = random.uniform(50, 150)
            
            self.target_depth = self.evasion_depth
            self.target_speed = self.max_speed * 0.9
            
            # Evasive course changes
            if random.random() < 0.05:  # 5% chance per update
                self.target_heading = (self.heading + random.uniform(30, 150)) % 360

    def _should_fire_torpedo(self, target_sub):
        """Determine if conditions are right to fire a torpedo."""
        current_time = time.time()
        if current_time - self.last_torpedo_shot < self.torpedo_reload_time:
            return False
            
        # Calculate range and bearing to target
        dx = target_sub.x - self.x
        dy = target_sub.y - self.y
        distance = math.hypot(dx, dy)
        
        # Check if target is within range
        if distance > self.torpedo_range:
            return False
            
        # Calculate relative motion
        relative_speed = math.hypot(
            target_sub.speed * math.sin(math.radians(target_sub.heading)) - 
            self.speed * math.sin(math.radians(self.heading)),
            target_sub.speed * math.cos(math.radians(target_sub.heading)) - 
            self.speed * math.cos(math.radians(self.heading))
        )
        
        # Don't fire if relative speed is too high
        if relative_speed > 40:
            return False
        
        # Calculate firing solution
        bearing_to_target = math.degrees(math.atan2(dx, -dy)) % 360
        bearing_difference = abs((bearing_to_target - self.heading + 180) % 360 - 180)
        
        # Only fire if we have a good firing angle
        if bearing_difference > 45:
            return False
        
        # Calculate probability of hit based on range and conditions
        hit_probability = 0.9  # Base probability
        hit_probability *= (1 - distance / self.torpedo_range)  # Range factor
        hit_probability *= (1 - relative_speed / 40)  # Speed factor
        
        # Random chance based on calculated probability
        return random.random() < hit_probability

    def _reached_last_known_position(self):
        """Check if submarine has reached its last known contact position."""
        if not self.last_known_contact:
            return True
            
        dx = self.last_known_contact[0] - self.x
        dy = self.last_known_contact[1] - self.y
        distance = math.hypot(dx, dy)
        
        return distance < 50  # Within 50 units of target position
        
    def can_fire_torpedo(self, current_time):
        """Check if submarine can fire a torpedo."""
        return (self.tubes_loaded > 0 and 
                current_time - self.last_torpedo_shot >= self.torpedo_reload_time)

def update_ai_behavior(self, current_time, player_sub):
    """Update AI behavior for enemy submarines."""
    if self.is_friendly:
        return
        
    dt = current_time - self.last_ai_update
    self.last_ai_update = current_time
    
    # Get detection status of player
    player_detected, detection_range = self.detect_target(player_sub)
    
    # Update AI state based on situation
    if self.ai_state == "patrol":
        if player_detected:
            self.ai_state = "hunting"
            self.last_known_contact = (player_sub.x, player_sub.y, player_sub.depth)
            print(f"Enemy sub transitioning to hunting mode at {self.x}, {self.y}")
    
    elif self.ai_state == "hunting":
        if not player_detected:
            self.ai_state = "last_known_position"
            print(f"Enemy sub lost contact, moving to last known position")
        else:
            self.last_known_contact = (player_sub.x, player_sub.y, player_sub.depth)
    
    elif self.ai_state == "last_known_position":
        if player_detected:
            self.ai_state = "hunting"
        elif self._reached_last_known_position():
            self.ai_state = "search_pattern"
            self.search_start_time = current_time
            self.search_center = (self.x, self.y)
            print(f"Enemy sub starting search pattern")
    
    elif self.ai_state == "search_pattern":
        if player_detected:
            self.ai_state = "hunting"
        elif current_time - self.search_start_time > 120:  # 2 minutes max search
            self.ai_state = "patrol"
            print(f"Enemy sub returning to patrol")
    
    elif self.ai_state == "evading":
        if not player_detected and current_time - self.evasion_start > 60:
            self.ai_state = "patrol"
            print(f"Enemy sub ending evasion")
    
    # Execute behavior based on state
    self._execute_ai_behavior(dt, player_sub)

def _execute_ai_behavior(self, dt, player_sub):
    """Execute specific AI behaviors based on current state."""
    if self.ai_state == "patrol":
        # Regular patrol behavior with improved randomization
        self.target_depth = self.patrol_depth
        
        # Occasionally change patrol parameters
        if random.random() < 0.02:  # 2% chance per update
            # Choose new heading based on current position
            if self.x < 200:  # Near left edge
                self.target_heading = random.uniform(-45, 45)
            elif self.x > 1000:  # Near right edge
                self.target_heading = random.uniform(135, 225)
            elif self.y < 200:  # Near top edge
                self.target_heading = random.uniform(45, 135)
            elif self.y > 600:  # Near bottom edge
                self.target_heading = random.uniform(225, 315)
            else:
                self.target_heading = random.uniform(0, 360)
            
            # Vary patrol depth
            self.patrol_depth = random.uniform(100, 300)
        
        # Maintain patrol speed
        self.target_speed = random.uniform(5, 12)
        
    elif self.ai_state == "hunting":
        # Enhanced hunting behavior with intercept calculations
        dx = player_sub.x - self.x
        dy = player_sub.y - self.y
        distance = math.hypot(dx, dy)
        
        # Calculate intercept course
        lead_time = distance / (self.max_speed * 0.5)  # Simplified intercept
        future_x = player_sub.x + (player_sub.speed * math.sin(math.radians(player_sub.heading)) * lead_time)
        future_y = player_sub.y - (player_sub.speed * math.cos(math.radians(player_sub.heading)) * lead_time)
        
        # Calculate heading to intercept point
        intercept_heading = math.degrees(math.atan2(future_x - self.x, -(future_y - self.y))) % 360
        self.target_heading = intercept_heading
        
        # Adjust depth based on target and thermal layers
        if abs(player_sub.depth - self.depth) > 50:
            self.target_depth = player_sub.depth
        
        # Set speed based on distance
        if distance < 200:
            self.target_speed = max(5, player_sub.speed - 2)  # Slow down for better tracking
        else:
            self.target_speed = min(20, self.max_speed * 0.8)
        
        # Fire torpedo if conditions are met
        if self._should_fire_torpedo(player_sub):
            self.fire_torpedo(self.target_heading)
        
    elif self.ai_state == "last_known_position":
        # Move to last known contact position
        if self.last_known_contact:
            dx = self.last_known_contact[0] - self.x
            dy = self.last_known_contact[1] - self.y
            self.target_heading = math.degrees(math.atan2(dx, -dy)) % 360
            self.target_depth = self.last_known_contact[2]
            self.target_speed = 15
        
    elif self.ai_state == "search_pattern":
        # Execute expanding spiral search pattern
        time_in_search = time.time() - self.search_start_time
        spiral_radius = 50 + (time_in_search * 2)  # Expanding radius
        angle = time_in_search * 0.5  # Rotation rate
        
        # Calculate position in spiral
        target_x = self.search_center[0] + spiral_radius * math.cos(angle)
        target_y = self.search_center[1] + spiral_radius * math.sin(angle)
        
        # Calculate heading to maintain spiral
        dx = target_x - self.x
        dy = target_y - self.y
        self.target_heading = math.degrees(math.atan2(dx, -dy)) % 360
        
        # Maintain search speed and depth
        self.target_speed = 10
        self.target_depth = 150  # Mid-depth for better sonar coverage
        
    elif self.ai_state == "evading":
        if not self.evasion_depth:
            # Choose evasion depth in different thermal layer
            if self.depth < 200:
                self.evasion_depth = random.uniform(250, self.test_depth)
            else:
                self.evasion_depth = random.uniform(50, 150)
        
        self.target_depth = self.evasion_depth
        self.target_speed = self.max_speed * 0.9
        
        # Evasive course changes
        if random.random() < 0.05:  # 5% chance per update
            self.target_heading = (self.heading + random.uniform(30, 150)) % 360

def _should_fire_torpedo(self, target_sub):
    """Determine if conditions are right to fire a torpedo."""
    current_time = time.time()
    if current_time - self.last_torpedo_shot < self.torpedo_reload_time:
        return False
        
    # Calculate range and bearing to target
    dx = target_sub.x - self.x
    dy = target_sub.y - self.y
    distance = math.hypot(dx, dy)
    
    # Check if target is within range
    if distance > self.torpedo_range:
        return False
        
    # Calculate relative motion
    relative_speed = math.hypot(
        target_sub.speed * math.sin(math.radians(target_sub.heading)) - 
        self.speed * math.sin(math.radians(self.heading)),
        target_sub.speed * math.cos(math.radians(target_sub.heading)) - 
        self.speed * math.cos(math.radians(self.heading))
    )
    
    # Don't fire if relative speed is too high
    if relative_speed > 40:
        return False
    
    # Calculate firing solution
    bearing_to_target = math.degrees(math.atan2(dx, -dy)) % 360
    bearing_difference = abs((bearing_to_target - self.heading + 180) % 360 - 180)
    
    # Only fire if we have a good firing angle
    if bearing_difference > 45:
        return False
    
    # Calculate probability of hit based on range and conditions
    hit_probability = 0.9  # Base probability
    hit_probability *= (1 - distance / self.torpedo_range)  # Range factor
    hit_probability *= (1 - relative_speed / 40)  # Speed factor
    
    # Random chance based on calculated probability
    return random.random() < hit_probability

def _reached_last_known_position(self):
    """Check if submarine has reached its last known contact position."""
    if not self.last_known_contact:
        return True
        
    dx = self.last_known_contact[0] - self.x
    dy = self.last_known_contact[1] - self.y
    distance = math.hypot(dx, dy)
    
    return distance < 50  # Within 50 units of target position

class Projectile:
    """Represents a gun projectile fired from surface ships."""
    def __init__(self, x, y, heading, speed=80.0):
        self.x = x
        self.y = y
        self.heading = heading
        self.speed = speed
        self.size = 3  # Smaller than torpedoes
        self.damage = 15  # Less damage than torpedoes
        self.track_history = deque(maxlen=20)  # Shorter trail than torpedoes
        self.is_active = True
        
        # Additional characteristics for surface fire
        self.max_range = 250  # Maximum effective range
        self.accuracy = 0.85  # Base accuracy (85%)
        self.damage_falloff_start = 150  # Range at which damage starts to fall off
        
    def calculate_damage(self, distance):
        """Calculate projectile damage based on range."""
        if distance > self.damage_falloff_start:
            # Reduce damage at longer ranges
            falloff_factor = 1 - ((distance - self.damage_falloff_start) / 
                                (self.max_range - self.damage_falloff_start))
            return self.damage * max(0.5, falloff_factor)
        return self.damage
        
    def calculate_hit_probability(self, distance, target_speed):
        """Calculate probability of hitting based on range and target speed."""
        # Base accuracy modified by range and target speed
        range_factor = 1 - (distance / self.max_range)
        speed_factor = 1 - (target_speed / 30)  # Assume max target speed of 30 knots
        return self.accuracy * range_factor * speed_factor

class Torpedo(Projectile):
    """Enhanced torpedo with improved guidance and underwater physics."""
    def __init__(self, x, y, heading, friendly=True, launch_depth=0):
        """Initialize torpedo with debugging."""
        # Call parent class initialization first
        super().__init__(x, y, heading, speed=55.0)
        
        # Override some parent class attributes
        self.friendly = friendly
        self.depth = launch_depth
        self.target_depth = launch_depth
        self.size = 4
        self.damage = random.uniform(65, 85)
        self.track_history = deque(maxlen=50)
        
        # Add torpedo-specific attributes
        self.max_depth_change_rate = 10.0  # Maximum depth change per second
        self.vertical_velocity = 0.0
        self.guidance_range = 200.0
        self.has_acquired_target = False
        self.last_known_target_pos = None
        self.track_quality = 1.0
        self.noise_factor = 0.0
        self.search_pattern_time = 0.0
        self.turn_rate = 3.0  # degrees per second
        self.search_angle = 45.0  # degrees
        
        print(f"Torpedo created at ({x:.1f}, {y:.1f}), Heading: {heading}°, Depth: {launch_depth}m")
        
    def update(self, dt, target_vessel):
        """Update torpedo position and tracking."""
        if not self.is_active:
            return
            
        # Update position
        heading_rad = math.radians(self.heading)
        dx = math.sin(heading_rad) * self.speed * dt
        dy = -math.cos(heading_rad) * self.speed * dt
        
        self.x += dx
        self.y += dy
        
        # Update depth
        self.update_depth(dt)
        
        # Check if target is in range
        if target_vessel and self.is_active:
            distance = math.hypot(target_vessel.x - self.x, target_vessel.y - self.y)
            
            if distance <= self.guidance_range:
                self.track_target(target_vessel, dt)
            else:
                self.search_pattern(dt)
                
        # Update tracking quality
        self.track_quality *= (1 - 0.1 * dt)  # Degrade tracking over time
        self.noise_factor += 0.1 * dt  # Increase noise over time
        
        # Deactivate if tracking is lost
        if self.track_quality < 0.2 or self.noise_factor > 2.0:
            self.is_active = False
            
    def track_target(self, target_vessel, dt):
        """Track and home in on target vessel."""
        # Calculate ideal heading to target
        dx = target_vessel.x - self.x
        dy = target_vessel.y - self.y
        ideal_heading = math.degrees(math.atan2(dx, -dy)) % 360
        
        # Add noise based on tracking quality
        heading_noise = random.gauss(0, 5 * (1 - self.track_quality))
        ideal_heading = (ideal_heading + heading_noise) % 360
        
        # Calculate heading difference
        heading_diff = (ideal_heading - self.heading + 180) % 360 - 180
        
        # Apply turn rate limit
        max_turn = self.turn_rate * dt
        if abs(heading_diff) > max_turn:
            heading_diff = math.copysign(max_turn, heading_diff)
            
        # Update heading
        self.heading = (self.heading + heading_diff) % 360
        
        # Update depth tracking
        if abs(target_vessel.depth - self.depth) > 10:
            self.target_depth = target_vessel.depth
            
    def search_pattern(self, dt):
        """Execute search pattern when target is lost."""
        self.search_pattern_time += dt
        
        # Spiral search pattern
        angle = self.search_pattern_time * 2
        radius = 20 + self.search_pattern_time * 5
        
        # Calculate desired heading for spiral
        spiral_heading = (self.heading + 30 * dt) % 360
        
        # Apply heading change with some randomness
        heading_diff = (spiral_heading - self.heading + 180) % 360 - 180
        max_turn = self.turn_rate * dt
        if abs(heading_diff) > max_turn:
            heading_diff = math.copysign(max_turn, heading_diff)
            
        self.heading = (self.heading + heading_diff) % 360
        
    def update_depth(self, dt):
        """Update torpedo depth."""
        depth_error = self.target_depth - self.depth
        desired_velocity = depth_error * 0.8
        
        if abs(desired_velocity) > self.max_depth_change_rate:
            desired_velocity = math.copysign(self.max_depth_change_rate, desired_velocity)
            
        self.vertical_velocity = (self.vertical_velocity * 0.8 + desired_velocity * 0.2)
        self.depth += self.vertical_velocity * dt
        
    def guide_to_target(self, target_x, target_y, target_depth, dt):
        """Guide torpedo towards target with enhanced underwater warfare capabilities."""
        if not self.is_active:
            return
            
        # Calculate distance to target
        dx = target_x - self.x
        dy = target_y - self.y
        distance = math.hypot(dx, dy)
        
        if distance <= self.guidance_range:
            # Calculate desired heading
            desired_heading = math.degrees(math.atan2(dx, -dy))
            
            # Calculate heading difference
            heading_diff = (desired_heading - self.heading + 180) % 360 - 180
            
            # Apply turn rate limit
            max_turn = self.turn_rate * dt
            if abs(heading_diff) > max_turn:
                heading_diff = math.copysign(max_turn, heading_diff)
            
            # Update heading
            self.heading = (self.heading + heading_diff) % 360
            
            # Update target depth
            depth_diff = target_depth - self.depth
            if abs(depth_diff) > 10:  # Only adjust depth if difference is significant
                self.target_depth = target_depth
            
            self.has_acquired_target = True
            self.last_known_target_pos = (target_x, target_y, target_depth)
        elif self.has_acquired_target and self.last_known_target_pos:
            # Continue towards last known position
            self.search_pattern_time += dt
            
            # Add search pattern if target lost
            search_angle = math.sin(self.search_pattern_time) * self.search_angle
            self.heading = (self.heading + search_angle * dt) % 360

class Projectile:
    """Represents a gun projectile fired from surface ships."""
    def __init__(self, x, y, heading, speed=80.0):
        self.x = x
        self.y = y
        self.heading = heading
        self.speed = speed
        self.size = 3  # Smaller than torpedoes
        self.damage = 15  # Less damage than torpedoes
        self.track_history = deque(maxlen=20)  # Shorter trail than torpedoes
        self.is_active = True
        
        # Additional characteristics for surface fire
        self.max_range = 250  # Maximum effective range
        self.accuracy = 0.85  # Base accuracy (85%)
        self.damage_falloff_start = 150  # Range at which damage starts to fall off
        
    def calculate_damage(self, distance):
        """Calculate projectile damage based on range."""
        if distance > self.damage_falloff_start:
            # Reduce damage at longer ranges
            falloff_factor = 1 - ((distance - self.damage_falloff_start) / 
                                (self.max_range - self.damage_falloff_start))
            return self.damage * max(0.5, falloff_factor)
        return self.damage
        
    def calculate_hit_probability(self, distance, target_speed):
        """Calculate probability of hitting based on range and target speed."""
        # Base accuracy modified by range and target speed
        range_factor = 1 - (distance / self.max_range)
        speed_factor = 1 - (target_speed / 30)  # Assume max target speed of 30 knots
        return self.accuracy * range_factor * speed_factor
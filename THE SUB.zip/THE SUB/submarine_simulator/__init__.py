# Core classes
from .ship_classes import (
    Ship,
    Submarine,
    Torpedo,
    Projectile,
    SubmarinePhysics
)

# GUI components
from .gui_elements import (
    SubmarineGUI,
    SonarContactDisplay,  # Changed from SonarContactPanel
    CombatStatsPanel,
    StealthPanel
)

# Main simulator
from .submarine_game import SubmarineSimulator

# Package metadata
__version__ = '1.0.0'
__author__ = 'Submarine Simulator Development Team'
__description__ = 'Advanced submarine warfare simulation with thermal layer physics'

# Export all public classes and components
__all__ = [
    # Core classes
    'Ship',
    'Submarine',
    'Torpedo',
    'Projectile',
    'SubmarinePhysics',
    
    # GUI components
    'SubmarineGUI',
    'SonarContactDisplay',  # Changed from SonarContactPanel
    'CombatStatsPanel',
    'StealthPanel',
    
    # Main simulator
    'SubmarineSimulator'
]